package com.handrummy.game.network

import android.content.Context
import android.util.Log
import com.handrummy.game.model.Game
import com.handrummy.game.model.Player
import com.handrummy.game.network.NetworkManager
import com.handrummy.game.network.NetworkProtocol
import java.util.*

/**
 * Client class that handles network connections and game state for clients (non-host players)
 */
class GameClient(
    private val context: Context,
    private val playerName: String,
    private val onGameStateUpdated: (Game) -> Unit,
    private val onPlayerJoined: (String) -> Unit,
    private val onPlayerLeft: (Int) -> Unit,
    private val onGameStarted: () -> Unit,
    private val onGameOver: (Int) -> Unit,
    private val onError: (String) -> Unit
) {

    companion object {
        private const val TAG = "GameClient"
    }

    // Network manager for handling connections
    private var networkManager: NetworkManager? = null
    
    // Current game state
    private var game: Game? = null
    
    // Client player ID
    private var playerId = -1
    
    /**
     * Initializes the network manager for the selected connection type
     */
    fun initializeNetworkManager(connectionType: NetworkManager.ConnectionType) {
        networkManager = NetworkManager(
            context,
            onDeviceFound = { },  // We don't need this in client mode after connection
            onConnectionSuccess = {
                // Send player join request
                sendPlayerJoinRequest()
            },
            onConnectionFailed = { error ->
                onError("Connection failed: $error")
            },
            onDataReceived = { data ->
                handleReceivedData(data)
            }
        )
        
        networkManager?.initializeConnectionType(connectionType)
    }
    
    /**
     * Connects to a host device
     */
    fun connectToHost(deviceInfo: NetworkManager.DeviceInfo) {
        networkManager?.connectToDevice(deviceInfo)
    }
    
    /**
     * Sends a player join request to the host
     */
    private fun sendPlayerJoinRequest() {
        val message = NetworkProtocol.createPlayerJoinMessage(-1, playerName)
        networkManager?.sendData(message)
    }
    
    /**
     * Processes messages received from the host
     */
    private fun handleReceivedData(data: String) {
        try {
            val messageParts = NetworkProtocol.parseMessage(data)
            if (messageParts == null) {
                Log.e(TAG, "Invalid message format: $data")
                return
            }
            
            val messageType = messageParts.first
            val messageContent = messageParts.second
            
            when (messageType) {
                NetworkProtocol.PLAYER_JOIN -> {
                    // Format: PLAYER_JOIN|playerId|playerName
                    val parts = messageContent.split(NetworkProtocol.FIELD_SEPARATOR)
                    if (parts.size >= 2) {
                        val joinedPlayerId = parts[0].toInt()
                        val joinedPlayerName = parts[1]
                        
                        // If this is our player ID assignment
                        if (playerId == -1) {
                            playerId = joinedPlayerId
                        }
                        
                        onPlayerJoined(joinedPlayerName)
                    }
                }
                
                NetworkProtocol.PLAYER_LEAVE -> {
                    val leftPlayerId = messageContent.toInt()
                    onPlayerLeft(leftPlayerId)
                }
                
                NetworkProtocol.GAME_START -> {
                    onGameStarted()
                    
                    // Request initial game state
                    networkManager?.sendData(NetworkProtocol.createRequestGameStateMessage())
                }
                
                NetworkProtocol.GAME_STATE_UPDATE -> {
                    // Deserialize game state
                    game = Game.deserialize(messageContent)
                    game?.let { onGameStateUpdated(it) }
                }
                
                NetworkProtocol.GAME_OVER -> {
                    val winnerId = messageContent.toInt()
                    onGameOver(winnerId)
                }
                
                NetworkProtocol.PING -> {
                    // Respond with pong message
                    networkManager?.sendData(NetworkProtocol.createPongMessage(messageContent))
                }
                
                NetworkProtocol.ERROR -> {
                    val parts = messageContent.split(NetworkProtocol.FIELD_SEPARATOR)
                    if (parts.size >= 2) {
                        val errorCode = parts[0].toInt()
                        val errorMessage = parts[1]
                        onError("Error $errorCode: $errorMessage")
                    }
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error processing message: ${e.message}")
        }
    }
    
    /**
     * Performs a player action
     */
    fun performAction(action: String, data: String = "") {
        val message = NetworkProtocol.createPlayerActionMessage(action, data)
        networkManager?.sendData(message)
    }
    
    /**
     * Requests the latest game state from the server
     */
    fun requestGameState() {
        networkManager?.sendData(NetworkProtocol.createRequestGameStateMessage())
    }
    
    /**
     * Gets the local player's ID
     */
    fun getPlayerId(): Int {
        return playerId
    }
    
    /**
     * Cleans up resources when the client is destroyed
     */
    fun cleanup() {
        networkManager?.cleanup()
        networkManager = null
    }
}