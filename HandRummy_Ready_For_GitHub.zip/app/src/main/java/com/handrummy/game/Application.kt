package com.handrummy.game

import android.app.Application
import android.content.Context
import com.handrummy.game.utils.LocaleHelper

/**
 * Custom Application class for Hands Rummy game.
 * Manages application-wide settings and configurations.
 */
class Application : Application() {

    override fun attachBaseContext(base: Context) {
        // Apply saved language setting
        super.attachBaseContext(LocaleHelper.onCreate(base))
    }

    override fun onCreate() {
        super.onCreate()
        // Initialize any application-wide services or configurations here
    }
}