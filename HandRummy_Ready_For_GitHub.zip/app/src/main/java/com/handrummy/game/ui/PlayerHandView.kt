package com.handrummy.game.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import androidx.core.content.ContextCompat
import com.handrummy.game.R
import com.handrummy.game.model.Card

/**
 * Custom view that displays the player's hand of cards.
 * Provides scrolling and card selection.
 */
class PlayerHandView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : HorizontalScrollView(context, attrs, defStyleAttr) {

    private val cardsContainer: FrameLayout
    private val cardViews = mutableListOf<CardView>()
    private var cards = mutableListOf<Card>()
    private var selectedCardIndex = -1
    private var cardSelectedListener: ((Card) -> Unit)? = null
    
    private val cardSpacing = 8 // Space between cards (in dp)
    private val cardWidth = CardView.DEFAULT_CARD_WIDTH
    private val cardHeight = CardView.DEFAULT_CARD_HEIGHT
    
    private val backgroundPaint = Paint()

    init {
        // Create container for cards
        cardsContainer = FrameLayout(context)
        val layoutParams = LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        cardsContainer.layoutParams = layoutParams
        
        // Add container to scroll view
        addView(cardsContainer)
        
        // Setup background paint
        backgroundPaint.color = ContextCompat.getColor(context, android.R.color.white)
        backgroundPaint.style = Paint.Style.FILL
        
        // Remove scrollbar
        isHorizontalScrollBarEnabled = false
    }

    /**
     * Set the listener to be called when a card is selected
     */
    fun setOnCardSelectedListener(listener: (Card) -> Unit) {
        cardSelectedListener = listener
    }

    /**
     * Set the cards to display in the player's hand
     */
    fun setCards(newCards: List<Card>) {
        // Handle changes in the card list
        if (newCards.isEmpty()) {
            clearCards()
            return
        }
        
        if (cards != newCards) {
            cards.clear()
            cards.addAll(newCards)
            refreshCardViews()
        }
    }

    /**
     * Clear all cards from the view
     */
    private fun clearCards() {
        cards.clear()
        cardsContainer.removeAllViews()
        cardViews.clear()
        selectedCardIndex = -1
    }

    /**
     * Refresh the card views based on the current cards
     */
    private fun refreshCardViews() {
        // Remove all views from container
        cardsContainer.removeAllViews()
        cardViews.clear()
        
        val density = resources.displayMetrics.density
        val cardSpacingPx = (cardSpacing * density).toInt()
        val pixelCardWidth = (cardWidth * density).toInt()
        
        // Add card views
        for (i in cards.indices) {
            val card = cards[i]
            val cardView = CardView(context)
            val layoutParams = FrameLayout.LayoutParams(
                pixelCardWidth,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            
            // Position card with overlap
            layoutParams.leftMargin = i * (pixelCardWidth - cardSpacingPx)
            
            cardView.layoutParams = layoutParams
            cardView.setCard(card, i == selectedCardIndex)
            
            // Setup click handling
            val cardIndex = i // Capture for lambda
            cardView.setOnClickListener {
                // Update selected card
                if (selectedCardIndex != -1 && selectedCardIndex < cardViews.size) {
                    cardViews[selectedCardIndex].setHighlighted(false)
                }
                
                selectedCardIndex = cardIndex
                cardView.setHighlighted(true)
                
                // Notify listener
                cardSelectedListener?.invoke(card)
            }
            
            cardsContainer.addView(cardView)
            cardViews.add(cardView)
        }
        
        // Set container width to accommodate all cards with overlap
        val containerWidth = if (cards.size > 0) {
            (cards.size - 1) * (pixelCardWidth - cardSpacingPx) + pixelCardWidth
        } else {
            0
        }
        
        val containerParams = cardsContainer.layoutParams
        containerParams.width = containerWidth
        cardsContainer.layoutParams = containerParams
        
        // Scroll to show all cards
        post { fullScroll(FOCUS_RIGHT) }
        
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        // Draw background
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), backgroundPaint)
        
        // Let scroll view handle the rest
        super.onDraw(canvas)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        // Handle scrolling and selection
        return super.onTouchEvent(ev)
    }
}