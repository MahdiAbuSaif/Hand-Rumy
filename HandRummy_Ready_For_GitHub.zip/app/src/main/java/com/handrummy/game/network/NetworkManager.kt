package com.handrummy.game.network

import android.content.Context

/**
 * Unified network manager that abstracts the connectivity method (Bluetooth or WiFi Direct).
 * Provides a common interface for network operations regardless of the underlying technology.
 */
class NetworkManager(
    private val context: Context,
    private val onDeviceFound: (DeviceInfo) -> Unit,
    private val onConnectionSuccess: () -> Unit,
    private val onConnectionFailed: (String) -> Unit,
    private val onDataReceived: (String) -> Unit
) {

    // Connection types
    enum class ConnectionType {
        BLUETOOTH,
        WIFI_DIRECT
    }

    // Data class to represent a discovered device
    data class DeviceInfo(
        val name: String,
        val address: String,
        val type: ConnectionType,
        val nativeDevice: Any // Raw device object (BluetoothDevice or WifiP2pDevice)
    )

    // Network managers for different connection types
    private var bluetoothManager: BluetoothManager? = null
    private var wifiDirectManager: WifiDirectManager? = null
    
    // Current active connection type
    private var activeConnectionType: ConnectionType? = null
    
    /**
     * Initializes the network manager for a specific connection type
     * 
     * @param type The connection type to initialize
     */
    fun initializeConnectionType(type: ConnectionType) {
        // Close any existing connections
        cleanup()
        
        when (type) {
            ConnectionType.BLUETOOTH -> {
                bluetoothManager = BluetoothManager(
                    context,
                    { device -> 
                        onDeviceFound(DeviceInfo(
                            device.name ?: "Unknown Device",
                            device.address,
                            ConnectionType.BLUETOOTH,
                            device
                        ))
                    },
                    onConnectionSuccess,
                    onConnectionFailed
                )
                
                // Set data reception listener
                bluetoothManager?.setOnDataReceivedListener { data ->
                    onDataReceived(data)
                }
                
                activeConnectionType = ConnectionType.BLUETOOTH
            }
            
            ConnectionType.WIFI_DIRECT -> {
                wifiDirectManager = WifiDirectManager(
                    context,
                    { device ->
                        onDeviceFound(DeviceInfo(
                            device.deviceName ?: "Unknown Device",
                            device.deviceAddress,
                            ConnectionType.WIFI_DIRECT,
                            device
                        ))
                    },
                    onConnectionSuccess,
                    onConnectionFailed
                )
                
                // Set data reception listener
                wifiDirectManager?.setOnDataReceivedListener { data ->
                    onDataReceived(data)
                }
                
                activeConnectionType = ConnectionType.WIFI_DIRECT
            }
        }
    }
    
    /**
     * Checks if the selected connection type is available on this device
     * 
     * @return True if the connection type is available, false otherwise
     */
    fun isConnectionTypeAvailable(): Boolean {
        return when (activeConnectionType) {
            ConnectionType.BLUETOOTH -> bluetoothManager?.isBluetoothAvailable() ?: false
            ConnectionType.WIFI_DIRECT -> wifiDirectManager?.isWifiDirectAvailable() ?: false
            null -> false
        }
    }
    
    /**
     * Makes this device discoverable to other devices
     * For Bluetooth, this starts a server socket
     * For WiFi Direct, this creates a group
     */
    fun makeDiscoverable() {
        when (activeConnectionType) {
            ConnectionType.BLUETOOTH -> bluetoothManager?.makeDiscoverable()
            ConnectionType.WIFI_DIRECT -> wifiDirectManager?.createGroup()
            null -> onConnectionFailed("No connection type initialized")
        }
    }
    
    /**
     * Starts discovering nearby devices
     * For Bluetooth, this starts scanning for Bluetooth devices
     * For WiFi Direct, this starts discovering peers
     */
    fun discoverDevices() {
        when (activeConnectionType) {
            ConnectionType.BLUETOOTH -> bluetoothManager?.discoverDevices()
            ConnectionType.WIFI_DIRECT -> wifiDirectManager?.discoverPeers()
            null -> onConnectionFailed("No connection type initialized")
        }
    }
    
    /**
     * Connects to a specific device
     * 
     * @param deviceInfo The device information to connect to
     */
    fun connectToDevice(deviceInfo: DeviceInfo) {
        when (deviceInfo.type) {
            ConnectionType.BLUETOOTH -> {
                val device = deviceInfo.nativeDevice as android.bluetooth.BluetoothDevice
                bluetoothManager?.connectToDevice(device)
            }
            ConnectionType.WIFI_DIRECT -> {
                val device = deviceInfo.nativeDevice as android.net.wifi.p2p.WifiP2pDevice
                wifiDirectManager?.connectToDevice(device)
            }
        }
    }
    
    /**
     * Sends data to the connected device
     * 
     * @param data The string data to send
     * @return True if the data was sent successfully, false otherwise
     */
    fun sendData(data: String): Boolean {
        return when (activeConnectionType) {
            ConnectionType.BLUETOOTH -> bluetoothManager?.sendData(data) ?: false
            ConnectionType.WIFI_DIRECT -> wifiDirectManager?.sendData(data) ?: false
            null -> false
        }
    }
    
    /**
     * Sends a message using the network protocol
     * 
     * @param type Message type
     * @param content Message content
     * @return True if the message was sent successfully, false otherwise
     */
    fun sendMessage(type: String, content: String): Boolean {
        val message = NetworkProtocol.createMessage(type, content)
        return sendData(message)
    }
    
    /**
     * Cleans up network resources
     */
    fun cleanup() {
        bluetoothManager?.cleanup()
        bluetoothManager = null
        
        wifiDirectManager?.cleanup()
        wifiDirectManager = null
        
        activeConnectionType = null
    }
}