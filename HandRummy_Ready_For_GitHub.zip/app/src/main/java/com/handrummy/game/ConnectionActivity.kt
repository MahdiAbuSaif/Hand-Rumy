package com.handrummy.game

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.net.wifi.p2p.WifiP2pDevice
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.handrummy.game.network.NetworkManager
import java.util.*

class ConnectionActivity : BaseActivity() {

    private lateinit var connectMethodRadioGroup: RadioGroup
    private lateinit var bluetoothRadioButton: RadioButton
    private lateinit var wifiDirectRadioButton: RadioButton
    private lateinit var devicesListView: ListView
    private lateinit var scanButton: Button
    private lateinit var makeDiscoverableButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusTextView: TextView

    private var isHost: Boolean = false
    private lateinit var networkManager: NetworkManager
    private val devicesList = ArrayList<NetworkManager.DeviceInfo>()
    private lateinit var devicesAdapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_connection)

        isHost = intent.getBooleanExtra("IS_HOST", false)
        
        // Initialize UI components
        initializeViews()
        
        // Initialize network manager
        initializeNetworkManager()
        
        // Setup listeners
        setupUIListeners()
        
        // Update UI based on host/client role
        updateUIForRole()
    }
    
    private fun initializeViews() {
        connectMethodRadioGroup = findViewById(R.id.connectMethodRadioGroup)
        bluetoothRadioButton = findViewById(R.id.bluetoothRadioButton)
        wifiDirectRadioButton = findViewById(R.id.wifiDirectRadioButton)
        devicesListView = findViewById(R.id.devicesListView)
        scanButton = findViewById(R.id.scanButton)
        makeDiscoverableButton = findViewById(R.id.makeDiscoverableButton)
        progressBar = findViewById(R.id.progressBar)
        statusTextView = findViewById(R.id.statusTextView)
        
        // Setup devices adapter
        devicesAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList<String>())
        devicesListView.adapter = devicesAdapter
    }
    
    private fun initializeNetworkManager() {
        networkManager = NetworkManager(
            this,
            onDeviceFound = { deviceInfo ->
                // Add device to list
                runOnUiThread {
                    if (!devicesList.contains(deviceInfo)) {
                        devicesList.add(deviceInfo)
                        devicesAdapter.add("${deviceInfo.name} (${if (deviceInfo.type == NetworkManager.ConnectionType.BLUETOOTH) "BT" else "WiFi"})")
                        devicesAdapter.notifyDataSetChanged()
                        
                        statusTextView.text = getString(R.string.device_found)
                    }
                }
            },
            onConnectionSuccess = {
                runOnUiThread {
                    statusTextView.text = getString(R.string.connection_established)
                    progressBar.visibility = View.GONE
                    
                    // Save connection type to preferences
                    val sharedPrefs = getSharedPreferences("HandRummyPrefs", MODE_PRIVATE)
                    val connectionTypeValue = if (bluetoothRadioButton.isChecked) 0 else 1
                    sharedPrefs.edit().putInt("CONNECTION_TYPE", connectionTypeValue).apply()
                    
                    // Start lobby activity
                    val intent = Intent(this, LobbyActivity::class.java)
                    intent.putExtra("IS_HOST", isHost)
                    startActivity(intent)
                    finish()
                }
            },
            onConnectionFailed = { error ->
                runOnUiThread {
                    progressBar.visibility = View.GONE
                    Toast.makeText(this, getString(R.string.connection_failed_toast, error), Toast.LENGTH_LONG).show()
                    statusTextView.text = getString(R.string.connection_failed, error)
                }
            },
            onDataReceived = { data ->
                // We don't expect data at this stage, it will be handled in LobbyActivity
            }
        )
    }
    
    private fun setupUIListeners() {
        // Radio group listener
        connectMethodRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.bluetoothRadioButton -> {
                    networkManager.initializeConnectionType(NetworkManager.ConnectionType.BLUETOOTH)
                    resetDevicesList()
                }
                R.id.wifiDirectRadioButton -> {
                    networkManager.initializeConnectionType(NetworkManager.ConnectionType.WIFI_DIRECT)
                    resetDevicesList()
                }
            }
        }
        
        // Scan button listener
        scanButton.setOnClickListener {
            if (!networkManager.isConnectionTypeAvailable()) {
                if (bluetoothRadioButton.isChecked) {
                    requestBluetoothEnable()
                } else {
                    Toast.makeText(this, "WiFi Direct not available on this device", Toast.LENGTH_SHORT).show()
                }
                return@setOnClickListener
            }
            
            resetDevicesList()
            progressBar.visibility = View.VISIBLE
            statusTextView.text = if (bluetoothRadioButton.isChecked) 
                                    getString(R.string.scanning_for_devices)
                                else
                                    getString(R.string.scanning_for_wifi_peers)
            
            networkManager.discoverDevices()
        }
        
        // Make discoverable button listener
        makeDiscoverableButton.setOnClickListener {
            if (!networkManager.isConnectionTypeAvailable()) {
                if (bluetoothRadioButton.isChecked) {
                    requestBluetoothEnable()
                } else {
                    Toast.makeText(this, "WiFi Direct not available on this device", Toast.LENGTH_SHORT).show()
                }
                return@setOnClickListener
            }
            
            progressBar.visibility = View.VISIBLE
            statusTextView.text = if (bluetoothRadioButton.isChecked) 
                                    getString(R.string.device_discoverable)
                                else
                                    getString(R.string.wifi_group_created)
            
            networkManager.makeDiscoverable()
        }
        
        // Device selection listener
        devicesListView.setOnItemClickListener { _, _, position, _ ->
            if (position < devicesList.size) {
                val selectedDevice = devicesList[position]
                
                progressBar.visibility = View.VISIBLE
                statusTextView.text = getString(R.string.waiting_for_selection)
                
                networkManager.connectToDevice(selectedDevice)
            }
        }
        
        // Set initial selection
        bluetoothRadioButton.isChecked = true
        networkManager.initializeConnectionType(NetworkManager.ConnectionType.BLUETOOTH)
    }
    
    private fun updateUIForRole() {
        if (isHost) {
            makeDiscoverableButton.visibility = View.VISIBLE
            scanButton.visibility = View.GONE
            devicesListView.visibility = View.GONE
        } else {
            makeDiscoverableButton.visibility = View.GONE
            scanButton.visibility = View.VISIBLE
            devicesListView.visibility = View.VISIBLE
        }
    }
    
    private fun resetDevicesList() {
        devicesList.clear()
        devicesAdapter.clear()
        devicesAdapter.notifyDataSetChanged()
    }
    
    private fun requestBluetoothEnable() {
        val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
            startActivity(enableBtIntent)
        } else {
            // We should have the permission since we requested it in MainActivity
            Toast.makeText(this, "Bluetooth permission not granted", Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onDestroy() {
        networkManager.cleanup()
        super.onDestroy()
    }
}