package com.handrummy.game

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import com.handrummy.game.model.Game
import com.handrummy.game.network.GameClient
import com.handrummy.game.network.GameServer
import com.handrummy.game.network.NetworkManager

class LobbyActivity : BaseActivity() {

    private lateinit var playerListView: ListView
    private lateinit var startGameButton: Button
    private lateinit var leaveButton: Button
    private lateinit var maxPlayersSeekBar: SeekBar
    private lateinit var maxPlayersTextView: TextView
    private lateinit var statusTextView: TextView
    private lateinit var waitingTextView: TextView
    
    private var isHost: Boolean = false
    private lateinit var playerAdapter: ArrayAdapter<String>
    private val playersList = ArrayList<String>()
    
    // Game server (for host) and client (for all players)
    private var gameServer: GameServer? = null
    private var gameClient: GameClient? = null
    
    // Currently selected connection type (from previous screen)
    private lateinit var connectionType: NetworkManager.ConnectionType
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lobby)
        
        isHost = intent.getBooleanExtra("IS_HOST", false)
        
        // Get connection type from shared preferences
        val sharedPrefs = getSharedPreferences("HandRummyPrefs", MODE_PRIVATE)
        val connectionTypeValue = sharedPrefs.getInt("CONNECTION_TYPE", 0)
        connectionType = if (connectionTypeValue == 1) 
                            NetworkManager.ConnectionType.WIFI_DIRECT 
                         else 
                            NetworkManager.ConnectionType.BLUETOOTH
        
        // Initialize UI components
        initializeViews()
        
        // Setup UI based on role (host/client)
        setupUIForRole()
        
        // Initialize network components based on role
        if (isHost) {
            initializeGameServer()
        } else {
            initializeGameClient()
        }
    }
    
    private fun initializeViews() {
        playerListView = findViewById(R.id.playerListView)
        startGameButton = findViewById(R.id.startGameButton)
        leaveButton = findViewById(R.id.leaveButton)
        maxPlayersSeekBar = findViewById(R.id.maxPlayersSeekBar)
        maxPlayersTextView = findViewById(R.id.maxPlayersTextView)
        statusTextView = findViewById(R.id.statusTextView)
        waitingTextView = findViewById(R.id.waitingTextView)
        
        // Setup player list adapter
        playerAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, playersList)
        playerListView.adapter = playerAdapter
        
        // Setup seek bar
        maxPlayersSeekBar.max = 2  // 2-4 players, so max position is 2
        maxPlayersSeekBar.progress = 2  // Default to 4 players
        updateMaxPlayersText()
        
        maxPlayersSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateMaxPlayersText()
            }
            
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        
        // Setup button listeners
        startGameButton.setOnClickListener {
            startGame()
        }
        
        leaveButton.setOnClickListener {
            leaveLobby()
        }
    }
    
    private fun setupUIForRole() {
        if (isHost) {
            // Host can configure game and start it
            startGameButton.visibility = View.VISIBLE
            maxPlayersSeekBar.visibility = View.VISIBLE
            maxPlayersTextView.visibility = View.VISIBLE
            waitingTextView.visibility = View.GONE
            
            // Add host to players list
            val hostName = getPlayerName() + " " + getString(R.string.you_host)
            playersList.add(hostName)
            playerAdapter.notifyDataSetChanged()
            
            statusTextView.text = getString(R.string.waiting_for_players)
        } else {
            // Client can only wait for host to start
            startGameButton.visibility = View.GONE
            maxPlayersSeekBar.visibility = View.GONE
            maxPlayersTextView.visibility = View.GONE
            waitingTextView.visibility = View.VISIBLE
            
            statusTextView.text = getString(R.string.connected_waiting_for_start)
        }
    }
    
    private fun updateMaxPlayersText() {
        val maxPlayers = maxPlayersSeekBar.progress + 2  // 2-4 players
        maxPlayersTextView.text = getString(R.string.max_players) + " $maxPlayers"
    }
    
    private fun getPlayerName(): String {
        // In a real app, we'd get this from settings or prompt the user
        return "Player" + (System.currentTimeMillis() % 1000)
    }
    
    private fun initializeGameServer() {
        val maxPlayers = maxPlayersSeekBar.progress + 2  // 2-4 players
        
        gameServer = GameServer(
            this,
            getPlayerName(),
            maxPlayers,
            onPlayerJoined = { playerName ->
                runOnUiThread {
                    playersList.add(playerName)
                    playerAdapter.notifyDataSetChanged()
                    Toast.makeText(this, getString(R.string.player_joined, playerName), Toast.LENGTH_SHORT).show()
                    
                    // Enable start button when we have at least 2 players
                    startGameButton.isEnabled = playersList.size >= 2
                }
            },
            onPlayerLeft = { playerId ->
                runOnUiThread {
                    // In a real implementation, we'd have a proper data structure to track players
                    // For now, we'll just show a toast
                    Toast.makeText(this, getString(R.string.player_left, "Player $playerId"), Toast.LENGTH_SHORT).show()
                }
            },
            onGameStateUpdated = { game ->
                // Start game activity when game state is received
                startGameActivity(game)
            },
            onError = { error ->
                runOnUiThread {
                    Toast.makeText(this, error, Toast.LENGTH_LONG).show()
                }
            }
        )
        
        // Initialize the server with the selected connection type
        gameServer?.initializeNetworkManager(connectionType)
        
        // Make the server discoverable to clients
        gameServer?.makeDiscoverable()
    }
    
    private fun initializeGameClient() {
        gameClient = GameClient(
            this,
            getPlayerName(),
            onGameStateUpdated = { game ->
                // Start game activity when game state is received
                startGameActivity(game)
            },
            onPlayerJoined = { playerName ->
                runOnUiThread {
                    playersList.add(playerName)
                    playerAdapter.notifyDataSetChanged()
                    Toast.makeText(this, getString(R.string.player_joined, playerName), Toast.LENGTH_SHORT).show()
                }
            },
            onPlayerLeft = { playerId ->
                runOnUiThread {
                    Toast.makeText(this, getString(R.string.player_left, "Player $playerId"), Toast.LENGTH_SHORT).show()
                }
            },
            onGameStarted = {
                runOnUiThread {
                    waitingTextView.text = getString(R.string.game_in_progress)
                    statusTextView.text = getString(R.string.game_in_progress)
                }
            },
            onGameOver = { winnerId ->
                // Handle game over
            },
            onError = { error ->
                runOnUiThread {
                    Toast.makeText(this, error, Toast.LENGTH_LONG).show()
                }
            }
        )
        
        // Initialize the client with the selected connection type
        gameClient?.initializeNetworkManager(connectionType)
    }
    
    private fun startGame() {
        if (playersList.size < 2) {
            Toast.makeText(this, "Need at least 2 players to start", Toast.LENGTH_SHORT).show()
            return
        }
        
        // Start the game if we're the host
        gameServer?.startGame()
    }
    
    private fun startGameActivity(game: Game) {
        val intent = Intent(this, GameActivity::class.java)
        // Pass any necessary data to GameActivity
        intent.putExtra("IS_HOST", isHost)
        startActivity(intent)
        finish()
    }
    
    private fun leaveLobby() {
        // Clean up and go back to the main menu
        finish()
    }
    
    override fun onDestroy() {
        // Clean up resources
        gameServer?.cleanup()
        gameClient?.cleanup()
        super.onDestroy()
    }
}