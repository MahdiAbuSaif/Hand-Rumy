package com.handrummy.game.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.handrummy.game.R
import com.handrummy.game.model.Card

/**
 * Custom view that represents a playing card.
 * Handles rendering of card based on suit and rank.
 */
class CardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    // Card properties
    private var card: Card? = null
    private var isHighlighted: Boolean = false
    
    // Drawing properties
    private val cardPaint = Paint()
    private val textPaint = Paint()
    private val cornerRadius = 16f
    private val margin = 8f
    
    // Card dimensions
    private val cardRect = RectF()
    private val textBounds = Rect()

    init {
        // Set up paint for card background
        cardPaint.isAntiAlias = true
        cardPaint.color = ContextCompat.getColor(context, android.R.color.white)
        
        // Set up paint for text
        textPaint.isAntiAlias = true
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.textSize = 24f
    }

    /**
     * Set the card to display
     */
    fun setCard(newCard: Card, highlighted: Boolean = false) {
        card = newCard
        isHighlighted = highlighted
        invalidate()
    }

    /**
     * Set whether the card is highlighted
     */
    fun setHighlighted(highlighted: Boolean) {
        if (isHighlighted != highlighted) {
            isHighlighted = highlighted
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cardRect.set(margin, margin, width - margin, height - margin)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        
        val card = this.card ?: return
        
        // Draw card background
        cardPaint.color = if (isHighlighted) 
            ContextCompat.getColor(context, R.color.playerActiveHighlight) 
        else 
            ContextCompat.getColor(context, android.R.color.white)
            
        canvas.drawRoundRect(cardRect, cornerRadius, cornerRadius, cardPaint)
        
        // Draw border
        cardPaint.style = Paint.Style.STROKE
        cardPaint.strokeWidth = 2f
        cardPaint.color = ContextCompat.getColor(context, android.R.color.darker_gray)
        canvas.drawRoundRect(cardRect, cornerRadius, cornerRadius, cardPaint)
        cardPaint.style = Paint.Style.FILL
        
        // Set color based on suit
        when (card.suit) {
            Card.SUIT_HEARTS -> textPaint.color = ContextCompat.getColor(context, R.color.cardHearts)
            Card.SUIT_DIAMONDS -> textPaint.color = ContextCompat.getColor(context, R.color.cardDiamonds)
            Card.SUIT_SPADES -> textPaint.color = ContextCompat.getColor(context, R.color.cardSpades)
            Card.SUIT_CLUBS -> textPaint.color = ContextCompat.getColor(context, R.color.cardClubs)
        }
        
        // Draw card symbol
        val cardText = card.getShortName()
        textPaint.getTextBounds(cardText, 0, cardText.length, textBounds)
        val textX = (width - textBounds.width()) / 2f
        val textY = (height + textBounds.height()) / 2f
        canvas.drawText(cardText, textX, textY, textPaint)
        
        // Draw small indicator in corner
        textPaint.textSize = 14f
        canvas.drawText(cardText, cardRect.left + 8f, cardRect.top + 16f, textPaint)
        canvas.drawText(cardText, cardRect.right - 24f, cardRect.bottom - 8f, textPaint)
        textPaint.textSize = 24f
    }

    companion object {
        const val DEFAULT_CARD_WIDTH = 120
        const val DEFAULT_CARD_HEIGHT = 160
    }
}