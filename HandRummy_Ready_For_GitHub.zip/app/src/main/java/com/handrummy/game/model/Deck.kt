package com.handrummy.game.model

import java.io.Serializable
import java.util.*

/**
 * Represents a deck of cards for the Hand Rummy game.
 */
class Deck : Serializable {
    
    // The cards in the deck
    private val cards = mutableListOf<Card>()
    
    // The discard pile
    private val discardPile = mutableListOf<Card>()
    
    /**
     * Create a new deck with standard 52 cards
     */
    init {
        reset()
    }
    
    /**
     * Reset the deck to its initial state (52 cards, shuffled)
     */
    fun reset() {
        cards.clear()
        discardPile.clear()
        
        // Add standard 52 cards
        for (suit in 0..3) {
            for (rank in 1..13) {
                cards.add(Card(suit, rank))
            }
        }
        
        // Add jokers (optional rule)
        // cards.add(Card(Card.SUIT_JOKER, Card.RANK_JOKER))
        // cards.add(Card(Card.SUIT_JOKER, Card.RANK_JOKER))
        
        // Shuffle the deck
        shuffle()
    }
    
    /**
     * Shuffle the remaining cards in the deck
     */
    fun shuffle() {
        cards.shuffle()
    }
    
    /**
     * Deal a specified number of cards to each player
     */
    fun dealCards(players: List<Player>, cardsPerPlayer: Int) {
        for (i in 0 until cardsPerPlayer) {
            for (player in players) {
                if (cards.isNotEmpty()) {
                    player.addCardToHand(drawCard())
                }
            }
        }
    }
    
    /**
     * Draw a card from the top of the deck
     */
    fun drawCard(): Card {
        if (cards.isEmpty()) {
            // If deck is empty, reshuffled the discard pile except for the top card
            if (discardPile.size > 1) {
                val topDiscard = discardPile.removeAt(discardPile.size - 1)
                cards.addAll(discardPile)
                discardPile.clear()
                discardPile.add(topDiscard)
                shuffle()
            } else {
                throw NoSuchElementException("Deck is empty and discard pile has only one card")
            }
        }
        
        return cards.removeAt(cards.size - 1)
    }
    
    /**
     * Draw a card from the discard pile
     */
    fun drawFromDiscard(): Card {
        if (discardPile.isEmpty()) {
            throw NoSuchElementException("Discard pile is empty")
        }
        
        return discardPile.removeAt(discardPile.size - 1)
    }
    
    /**
     * Add a card to the discard pile
     */
    fun discard(card: Card) {
        discardPile.add(card)
    }
    
    /**
     * Get the top card from the discard pile without removing it
     */
    fun peekTopDiscard(): Card? {
        return if (discardPile.isEmpty()) null else discardPile.last()
    }
    
    /**
     * Get the number of cards remaining in the deck
     */
    fun getCardCount(): Int {
        return cards.size
    }
    
    /**
     * Get the number of cards in the discard pile
     */
    fun getDiscardCount(): Int {
        return discardPile.size
    }
    
    /**
     * Serialize the deck to a string
     */
    fun serialize(): String {
        val sb = StringBuilder()
        
        // Serialize cards in deck
        sb.append(cards.size)
        for (card in cards) {
            sb.append(";${card.serialize()}")
        }
        
        // Serialize discard pile
        sb.append("|${discardPile.size}")
        for (card in discardPile) {
            sb.append(";${card.serialize()}")
        }
        
        return sb.toString()
    }
    
    /**
     * Create a deck from a serialized string
     */
    companion object {
        fun fromString(serialized: String): Deck {
            val deck = Deck()
            deck.cards.clear()
            deck.discardPile.clear()
            
            val parts = serialized.split("|")
            if (parts.size != 2) {
                throw IllegalArgumentException("Invalid deck format")
            }
            
            // Deserialize cards in deck
            val deckParts = parts[0].split(";")
            val deckSize = deckParts[0].toInt()
            for (i in 1..deckSize) {
                deck.cards.add(Card.fromString(deckParts[i]))
            }
            
            // Deserialize discard pile
            val discardParts = parts[1].split(";")
            val discardSize = discardParts[0].toInt()
            for (i in 1..discardSize) {
                deck.discardPile.add(Card.fromString(discardParts[i]))
            }
            
            return deck
        }
    }
}