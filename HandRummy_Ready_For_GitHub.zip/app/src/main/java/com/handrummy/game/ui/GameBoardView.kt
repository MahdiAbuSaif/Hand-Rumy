package com.handrummy.game.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.handrummy.game.R
import com.handrummy.game.model.Card
import com.handrummy.game.model.Game
import com.handrummy.game.model.Meld

/**
 * Custom view that displays the game board, including:
 * - Draw pile
 * - Discard pile
 * - Melds on the table
 * - Opponent hands (face down)
 */
class GameBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var game: Game? = null
    private val melds = mutableListOf<Meld>()
    private val drawPileRect = RectF()
    private val discardPileRect = RectF()
    private val meldRects = mutableListOf<RectF>()
    private val opponentHandRects = mutableListOf<RectF>()
    
    private val backgroundPaint = Paint()
    private val cardPaint = Paint()
    private val textPaint = Paint()
    
    init {
        // Initialize paints
        backgroundPaint.color = ContextCompat.getColor(context, R.color.boardBackground)
        backgroundPaint.style = Paint.Style.FILL
        
        cardPaint.isAntiAlias = true
        cardPaint.color = ContextCompat.getColor(context, android.R.color.white)
        cardPaint.style = Paint.Style.FILL
        
        textPaint.isAntiAlias = true
        textPaint.color = ContextCompat.getColor(context, android.R.color.white)
        textPaint.textSize = 24f
    }

    /**
     * Set the game to display
     */
    fun setGame(game: Game) {
        this.game = game
        updateFromGame()
        invalidate()
    }

    /**
     * Update the view based on the current game state
     */
    private fun updateFromGame() {
        game?.let { currentGame ->
            // Update melds on the table
            melds.clear()
            melds.addAll(currentGame.getMelds())
            
            // Force layout recalculation
            requestLayout()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        
        // Calculate card sizes and positions based on the view dimensions
        val margin = 16
        val cardWidth = (width - margin * 6) / 5
        val cardHeight = cardWidth * 1.4f
        
        // Set draw pile rect
        drawPileRect.set(
            margin.toFloat(),
            (height / 2 - cardHeight / 2),
            (margin + cardWidth).toFloat(),
            (height / 2 + cardHeight / 2)
        )
        
        // Set discard pile rect
        discardPileRect.set(
            (margin * 2 + cardWidth).toFloat(),
            (height / 2 - cardHeight / 2),
            (margin * 2 + cardWidth * 2).toFloat(),
            (height / 2 + cardHeight / 2)
        )
        
        // Reset meld rects
        meldRects.clear()
        
        // Calculate meld rects
        val meldY = height / 2 - cardHeight - margin * 2
        for (i in 0 until 3) { // Max 3 visible melds
            val meldRect = RectF(
                (margin * 3 + cardWidth * 2 + i * (cardWidth + margin)).toFloat(),
                meldY,
                (margin * 3 + cardWidth * 3 + i * (cardWidth + margin)).toFloat(),
                meldY + cardHeight
            )
            meldRects.add(meldRect)
        }
        
        // Calculate opponent hand rects
        opponentHandRects.clear()
        val playerRadius = 120f
        val centerX = width / 2f
        val centerY = height / 2f
        
        // Top player (opposite)
        opponentHandRects.add(RectF(
            centerX - playerRadius,
            margin.toFloat(),
            centerX + playerRadius,
            margin + cardHeight
        ))
        
        // Left player
        opponentHandRects.add(RectF(
            margin.toFloat(),
            centerY - cardHeight * 2,
            margin + cardWidth,
            centerY - cardHeight
        ))
        
        // Right player
        opponentHandRects.add(RectF(
            width - margin - cardWidth.toFloat(),
            centerY - cardHeight * 2,
            width - margin.toFloat(),
            centerY - cardHeight
        ))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        
        // Draw background
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), backgroundPaint)
        
        // Draw draw pile
        drawCardPile(canvas, drawPileRect, "Draw")
        
        // Draw discard pile
        val topDiscard = game?.getTopDiscard()
        if (topDiscard != null) {
            drawCard(canvas, discardPileRect, topDiscard)
        } else {
            drawCardOutline(canvas, discardPileRect, "Empty")
        }
        
        // Draw melds
        for (i in melds.indices.take(3)) { // Only show up to 3 melds
            if (i < meldRects.size) {
                drawMeld(canvas, meldRects[i], melds[i])
            }
        }
        
        // Draw opponent hands
        game?.let { currentGame ->
            val players = currentGame.getPlayers()
            // Skip local player (player 0 or as reported by game)
            for (i in players.indices.drop(1).take(3)) {
                if (i - 1 < opponentHandRects.size) {
                    val opponentRect = opponentHandRects[i - 1]
                    val cardCount = players[i].hand.size
                    drawOpponentHand(canvas, opponentRect, cardCount, i)
                }
            }
        }
    }

    private fun drawCardPile(canvas: Canvas, rect: RectF, label: String) {
        // Draw card back
        cardPaint.color = ContextCompat.getColor(context, R.color.colorPrimaryDark)
        canvas.drawRoundRect(rect, 8f, 8f, cardPaint)
        
        // Draw border
        cardPaint.style = Paint.Style.STROKE
        cardPaint.strokeWidth = 2f
        cardPaint.color = ContextCompat.getColor(context, android.R.color.black)
        canvas.drawRoundRect(rect, 8f, 8f, cardPaint)
        cardPaint.style = Paint.Style.FILL
        
        // Draw label
        textPaint.color = ContextCompat.getColor(context, android.R.color.white)
        textPaint.textSize = 20f
        val textWidth = textPaint.measureText(label)
        val textX = rect.centerX() - textWidth / 2
        val textY = rect.centerY() + 8
        canvas.drawText(label, textX, textY, textPaint)
    }

    private fun drawCard(canvas: Canvas, rect: RectF, card: Card) {
        // Draw card background
        cardPaint.color = ContextCompat.getColor(context, android.R.color.white)
        canvas.drawRoundRect(rect, 8f, 8f, cardPaint)
        
        // Draw border
        cardPaint.style = Paint.Style.STROKE
        cardPaint.strokeWidth = 2f
        cardPaint.color = ContextCompat.getColor(context, android.R.color.darker_gray)
        canvas.drawRoundRect(rect, 8f, 8f, cardPaint)
        cardPaint.style = Paint.Style.FILL
        
        // Set color based on suit
        when (card.suit) {
            Card.SUIT_HEARTS -> textPaint.color = ContextCompat.getColor(context, R.color.cardHearts)
            Card.SUIT_DIAMONDS -> textPaint.color = ContextCompat.getColor(context, R.color.cardDiamonds)
            Card.SUIT_SPADES -> textPaint.color = ContextCompat.getColor(context, R.color.cardSpades)
            Card.SUIT_CLUBS -> textPaint.color = ContextCompat.getColor(context, R.color.cardClubs)
        }
        
        // Draw card symbol
        textPaint.textSize = 28f
        val cardText = card.getShortName()
        val textWidth = textPaint.measureText(cardText)
        val textX = rect.centerX() - textWidth / 2
        val textY = rect.centerY() + 10
        canvas.drawText(cardText, textX, textY, textPaint)
    }

    private fun drawCardOutline(canvas: Canvas, rect: RectF, label: String) {
        // Draw card outline
        cardPaint.style = Paint.Style.STROKE
        cardPaint.strokeWidth = 2f
        cardPaint.color = ContextCompat.getColor(context, android.R.color.white)
        canvas.drawRoundRect(rect, 8f, 8f, cardPaint)
        cardPaint.style = Paint.Style.FILL
        
        // Draw label
        textPaint.color = ContextCompat.getColor(context, android.R.color.white)
        textPaint.textSize = 20f
        val textWidth = textPaint.measureText(label)
        val textX = rect.centerX() - textWidth / 2
        val textY = rect.centerY() + 8
        canvas.drawText(label, textX, textY, textPaint)
    }

    private fun drawMeld(canvas: Canvas, rect: RectF, meld: Meld) {
        // Draw meld background
        cardPaint.color = ContextCompat.getColor(context, R.color.colorPrimary)
        canvas.drawRoundRect(rect, 8f, 8f, cardPaint)
        
        // Draw border
        cardPaint.style = Paint.Style.STROKE
        cardPaint.strokeWidth = 2f
        cardPaint.color = ContextCompat.getColor(context, android.R.color.black)
        canvas.drawRoundRect(rect, 8f, 8f, cardPaint)
        cardPaint.style = Paint.Style.FILL
        
        // Draw meld info
        textPaint.color = ContextCompat.getColor(context, android.R.color.white)
        textPaint.textSize = 18f
        
        val meldTypeText = when (meld.type) {
            Meld.TYPE_SET -> "Set"
            Meld.TYPE_RUN -> "Run"
            else -> "Meld"
        }
        
        val meldText = "$meldTypeText (${meld.cards.size})"
        val textWidth = textPaint.measureText(meldText)
        val textX = rect.centerX() - textWidth / 2
        val textY = rect.centerY() - 10
        
        canvas.drawText(meldText, textX, textY, textPaint)
        
        // Draw first card rank
        if (meld.cards.isNotEmpty()) {
            textPaint.textSize = 24f
            val cardRank = meld.cards[0].getShortName()
            val rankWidth = textPaint.measureText(cardRank)
            val rankX = rect.centerX() - rankWidth / 2
            val rankY = rect.centerY() + 20
            
            canvas.drawText(cardRank, rankX, rankY, textPaint)
        }
    }

    private fun drawOpponentHand(canvas: Canvas, rect: RectF, cardCount: Int, playerId: Int) {
        // Draw player background
        val isCurrentTurn = game?.getCurrentPlayerId() == playerId
        
        cardPaint.color = if (isCurrentTurn) 
            ContextCompat.getColor(context, R.color.playerActiveHighlight)
        else 
            ContextCompat.getColor(context, R.color.colorSecondary)
            
        canvas.drawRoundRect(rect, 8f, 8f, cardPaint)
        
        // Draw border
        cardPaint.style = Paint.Style.STROKE
        cardPaint.strokeWidth = 2f
        cardPaint.color = ContextCompat.getColor(context, android.R.color.black)
        canvas.drawRoundRect(rect, 8f, 8f, cardPaint)
        cardPaint.style = Paint.Style.FILL
        
        // Draw player info
        textPaint.color = ContextCompat.getColor(context, android.R.color.white)
        textPaint.textSize = 18f
        
        val playerText = "Player $playerId"
        val textWidth = textPaint.measureText(playerText)
        val textX = rect.centerX() - textWidth / 2
        val textY = rect.centerY() - 10
        
        canvas.drawText(playerText, textX, textY, textPaint)
        
        // Draw card count
        textPaint.textSize = 16f
        val countText = "$cardCount cards"
        val countWidth = textPaint.measureText(countText)
        val countX = rect.centerX() - countWidth / 2
        val countY = rect.centerY() + 20
        
        canvas.drawText(countText, countX, countY, textPaint)
    }
}