package com.handrummy.game.model

import java.io.Serializable

/**
 * Represents the main game state for Hand Rummy.
 */
class Game : Serializable {
    
    // Game constants
    companion object {
        const val MAX_PLAYERS = 4
        const val INITIAL_CARDS = 10 // Number of cards per player at start
        const val MIN_MELD_SCORE = 51 // Minimum score needed for initial meld
    }
    
    // Game components
    private val deck = Deck()
    private val players = mutableListOf<Player>()
    private val melds = mutableListOf<Meld>() // Melds on the table
    
    // Game state
    private var currentPlayerIndex = 0
    private var currentPlayerHasDrawn = false
    private var gameOver = false
    private var winnerId = -1
    
    /**
     * Initialize a new game with the given number of players
     */
    fun initialize(numPlayers: Int) {
        if (numPlayers < 2 || numPlayers > MAX_PLAYERS) {
            throw IllegalArgumentException("Number of players must be between 2 and $MAX_PLAYERS")
        }
        
        // Reset game state
        deck.reset()
        players.clear()
        melds.clear()
        currentPlayerIndex = 0
        currentPlayerHasDrawn = false
        gameOver = false
        winnerId = -1
        
        // Create players
        for (i in 0 until numPlayers) {
            players.add(Player(i))
        }
        
        // Deal initial cards
        deck.dealCards(players, INITIAL_CARDS)
    }
    
    /**
     * Start a player's turn
     */
    fun startTurn() {
        currentPlayerHasDrawn = false
    }
    
    /**
     * End the current player's turn and move to the next player
     */
    fun endTurn() {
        // Move to next player
        currentPlayerIndex = (currentPlayerIndex + 1) % players.size
        currentPlayerHasDrawn = false
    }
    
    /**
     * Process a player's action
     */
    fun processAction(playerId: Int, action: String, data: String = ""): Boolean {
        // Check if game is over
        if (gameOver) {
            return false
        }
        
        // Check if it's the player's turn
        if (playerId != currentPlayerIndex) {
            return false
        }
        
        // Process the action
        when (action) {
            NetworkProtocol.Action.DRAW_FROM_DECK -> {
                if (currentPlayerHasDrawn) {
                    return false
                }
                
                val card = deck.drawCard()
                players[playerId].addCardToHand(card)
                currentPlayerHasDrawn = true
                return true
            }
            
            NetworkProtocol.Action.DRAW_FROM_DISCARD -> {
                if (currentPlayerHasDrawn) {
                    return false
                }
                
                val card = deck.drawFromDiscard()
                players[playerId].addCardToHand(card)
                currentPlayerHasDrawn = true
                return true
            }
            
            NetworkProtocol.Action.DISCARD -> {
                if (!currentPlayerHasDrawn) {
                    return false
                }
                
                // Check if the player has the card
                val card = Card.fromString(data)
                if (!players[playerId].removeCardFromHand(card)) {
                    return false
                }
                
                // Add to discard pile
                deck.discard(card)
                endTurn()
                return true
            }
            
            NetworkProtocol.Action.DECLARE_MELD -> {
                if (!currentPlayerHasDrawn) {
                    return false
                }
                
                // Create meld from data
                val meld = Meld.fromString(data)
                
                // Check if player can declare this meld
                if (!players[playerId].declareMeld(meld)) {
                    return false
                }
                
                // Add to table melds
                melds.add(meld)
                
                // Check for rummy
                if (players[playerId].hasRummy()) {
                    declareWinner(playerId)
                }
                
                return true
            }
            
            NetworkProtocol.Action.ADD_TO_MELD -> {
                if (!currentPlayerHasDrawn) {
                    return false
                }
                
                // Parse meld index and card
                val parts = data.split("|")
                if (parts.size != 2) {
                    return false
                }
                
                val meldIndex = parts[0].toInt()
                val card = Card.fromString(parts[1])
                
                // Check if player can add to this meld
                if (!players[playerId].addCardToMeld(meldIndex, card)) {
                    return false
                }
                
                // Check for rummy
                if (players[playerId].hasRummy()) {
                    declareWinner(playerId)
                }
                
                return true
            }
            
            NetworkProtocol.Action.DECLARE_RUMMY -> {
                if (players[playerId].hasRummy()) {
                    declareWinner(playerId)
                    return true
                }
                
                return false
            }
            
            else -> return false
        }
    }
    
    /**
     * Declare a winner and end the game
     */
    private fun declareWinner(playerId: Int) {
        gameOver = true
        winnerId = playerId
    }
    
    /**
     * Get the ID of the current player
     */
    fun getCurrentPlayerId(): Int {
        return currentPlayerIndex
    }
    
    /**
     * Check if the current player has drawn a card
     */
    fun currentPlayerHasDrawn(): Boolean {
        return currentPlayerHasDrawn
    }
    
    /**
     * Get the list of players
     */
    fun getPlayers(): List<Player> {
        return players
    }
    
    /**
     * Get a player by their ID
     */
    fun getPlayerById(playerId: Int): Player? {
        return players.find { it.id == playerId }
    }
    
    /**
     * Get the deck
     */
    fun getDeck(): Deck {
        return deck
    }
    
    /**
     * Get the top discard card
     */
    fun getTopDiscard(): Card? {
        return deck.peekTopDiscard()
    }
    
    /**
     * Get the melds on the table
     */
    fun getMelds(): List<Meld> {
        return melds
    }
    
    /**
     * Check if the game is over
     */
    fun isGameOver(): Boolean {
        return gameOver
    }
    
    /**
     * Get the winner's ID (-1 if no winner yet)
     */
    fun getWinnerId(): Int {
        return winnerId
    }
    
    /**
     * Serialize the game state to a string
     */
    fun serialize(): String {
        val sb = StringBuilder()
        
        // Serialize game state
        sb.append("$currentPlayerIndex|$currentPlayerHasDrawn|$gameOver|$winnerId")
        
        // Serialize deck
        sb.append("|${deck.serialize()}")
        
        // Serialize players
        sb.append("|${players.size}")
        for (player in players) {
            sb.append("!${player.serialize()}")
        }
        
        // Serialize melds
        sb.append("|${melds.size}")
        for (meld in melds) {
            sb.append("!${meld.serialize()}")
        }
        
        return sb.toString()
    }
    
    /**
     * Create a game from a serialized string
     */
    companion object {
        fun fromString(serialized: String): Game {
            val game = Game()
            
            val parts = serialized.split("|")
            if (parts.size < 6) {
                throw IllegalArgumentException("Invalid game format: $serialized")
            }
            
            // Deserialize game state
            game.currentPlayerIndex = parts[0].toInt()
            game.currentPlayerHasDrawn = parts[1].toBoolean()
            game.gameOver = parts[2].toBoolean()
            game.winnerId = parts[3].toInt()
            
            // Deserialize deck
            val deckData = parts[4]
            game.deck.fromString(deckData)
            
            // Deserialize players
            val playerCount = parts[5].toInt()
            val playerParts = parts[6].split("!")
            for (i in 1..playerCount) {
                game.players.add(Player.fromString(playerParts[i]))
            }
            
            // Deserialize melds
            if (parts.size > 7) {
                val meldCount = parts[7].toInt()
                val meldParts = parts[8].split("!")
                for (i in 1..meldCount) {
                    game.melds.add(Meld.fromString(meldParts[i]))
                }
            }
            
            return game
        }
    }
}