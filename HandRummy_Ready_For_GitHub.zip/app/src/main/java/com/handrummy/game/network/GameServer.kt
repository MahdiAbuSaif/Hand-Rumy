package com.handrummy.game.network

import android.content.Context
import android.util.Log
import com.handrummy.game.model.Game
import com.handrummy.game.model.Player
import java.util.*
import kotlin.collections.HashMap

/**
 * Server class that manages the game state and handles communication with clients
 */
class GameServer(
    private val context: Context,
    private val hostPlayerName: String,
    private val maxPlayers: Int,
    private val onPlayerJoined: (String) -> Unit,
    private val onPlayerLeft: (Int) -> Unit,
    private val onGameStateUpdated: (Game) -> Unit,
    private val onError: (String) -> Unit
) {

    companion object {
        private const val TAG = "GameServer"
        private const val PING_INTERVAL = 10000L // 10 seconds
    }

    // Network manager for handling connections
    private var networkManager: NetworkManager? = null
    
    // Game instance
    private var game: Game? = null
    
    // Map of connected players by ID
    private val connectedPlayers = HashMap<Int, String>()
    
    // Host player ID (always 0)
    private val hostPlayerId = 0
    
    // Next player ID to assign
    private var nextPlayerId = 1
    
    // Flag indicating if game has started
    private var gameStarted = false
    
    // Timer for sending ping messages
    private var pingTimer: Timer? = null
    
    /**
     * Initializes the network manager for the selected connection type
     */
    fun initializeNetworkManager(connectionType: NetworkManager.ConnectionType) {
        networkManager = NetworkManager(
            context,
            onDeviceFound = { },  // We don't need this in server mode
            onConnectionSuccess = {
                // Connection established, add local player
                addLocalPlayer()
            },
            onConnectionFailed = { error ->
                onError("Connection failed: $error")
            },
            onDataReceived = { data ->
                handleReceivedData(data)
            }
        )
        
        networkManager?.initializeConnectionType(connectionType)
    }
    
    /**
     * Makes the server discoverable to clients
     */
    fun makeDiscoverable() {
        networkManager?.makeDiscoverable()
    }
    
    /**
     * Adds the local (host) player to the game
     */
    private fun addLocalPlayer() {
        connectedPlayers[hostPlayerId] = hostPlayerName
        
        // Initialize the game with the host player
        game = Game()
        game?.addPlayer(Player(hostPlayerId, hostPlayerName, true))
        
        onPlayerJoined(hostPlayerName)
    }
    
    /**
     * Processes messages received from clients
     */
    private fun handleReceivedData(data: String) {
        try {
            val messageParts = NetworkProtocol.parseMessage(data)
            if (messageParts == null) {
                Log.e(TAG, "Invalid message format: $data")
                return
            }
            
            val messageType = messageParts.first
            val messageContent = messageParts.second
            
            when (messageType) {
                NetworkProtocol.PLAYER_JOIN -> {
                    // Format: PLAYER_JOIN|-1|playerName (client sends -1 as temp ID)
                    val parts = messageContent.split(NetworkProtocol.FIELD_SEPARATOR)
                    if (parts.size >= 2) {
                        val playerName = parts[1]
                        
                        // Check if we can add more players
                        if (connectedPlayers.size >= maxPlayers) {
                            sendError(999, "Game is full (max $maxPlayers players)")
                            return
                        }
                        
                        // Check if game has already started
                        if (gameStarted) {
                            sendError(998, "Game has already started")
                            return
                        }
                        
                        // Assign player ID and add to game
                        val playerId = nextPlayerId++
                        connectedPlayers[playerId] = playerName
                        
                        // Add player to game
                        game?.addPlayer(Player(playerId, playerName, false))
                        
                        // Notify all clients about the new player
                        broadcastPlayerJoin(playerId, playerName)
                        
                        // Update game state
                        broadcastGameState()
                        
                        onPlayerJoined(playerName)
                    }
                }
                
                NetworkProtocol.PLAYER_ACTION -> {
                    if (!gameStarted) {
                        sendError(997, "Game has not started yet")
                        return
                    }
                    
                    val parts = messageContent.split(NetworkProtocol.FIELD_SEPARATOR)
                    if (parts.size >= 2) {
                        val action = parts[0]
                        val actionData = parts[1]
                        
                        // Process the player action
                        processPlayerAction(action, actionData)
                        
                        // Update game state
                        broadcastGameState()
                    }
                }
                
                NetworkProtocol.REQUEST_GAME_STATE -> {
                    // Client wants the current game state
                    broadcastGameState()
                }
                
                NetworkProtocol.PONG -> {
                    // Client responded to ping, update last seen time
                    // In a real implementation, we'd track connection health here
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error processing message: ${e.message}")
        }
    }
    
    /**
     * Processes a player action
     */
    private fun processPlayerAction(action: String, data: String) {
        // The player ID would be extracted from the data in a real implementation
        // For now, we just log the action
        Log.d(TAG, "Player action: $action, data: $data")
        
        // Update game based on action
        game?.let { currentGame ->
            when (action) {
                NetworkProtocol.Action.DRAW_FROM_DECK -> {
                    // Implement draw logic
                }
                
                NetworkProtocol.Action.DRAW_FROM_DISCARD -> {
                    // Implement draw from discard logic
                }
                
                NetworkProtocol.Action.DISCARD -> {
                    // Implement discard logic
                }
                
                NetworkProtocol.Action.DECLARE_MELD -> {
                    // Implement meld declaration logic
                }
                
                NetworkProtocol.Action.DECLARE_RUMMY -> {
                    // Implement rummy declaration logic
                    // If valid, send game over message
                    val playerId = data.toIntOrNull() ?: return
                    broadcastGameOver(playerId)
                }
            }
        }
    }
    
    /**
     * Broadcasts a player join message to all clients
     */
    private fun broadcastPlayerJoin(playerId: Int, playerName: String) {
        val message = NetworkProtocol.createPlayerJoinMessage(playerId, playerName)
        networkManager?.sendData(message)
    }
    
    /**
     * Broadcasts the current game state to all clients
     */
    private fun broadcastGameState() {
        game?.let {
            val gameState = it.serialize()
            val message = NetworkProtocol.createGameStateMessage(gameState)
            networkManager?.sendData(message)
            
            // Also update local UI
            onGameStateUpdated(it)
        }
    }
    
    /**
     * Broadcasts a game over message to all clients
     */
    private fun broadcastGameOver(winnerId: Int) {
        val message = NetworkProtocol.createGameOverMessage(winnerId)
        networkManager?.sendData(message)
    }
    
    /**
     * Sends an error message to clients
     */
    private fun sendError(errorCode: Int, errorMessage: String) {
        val message = NetworkProtocol.createErrorMessage(errorCode, errorMessage)
        networkManager?.sendData(message)
    }
    
    /**
     * Starts the game
     */
    fun startGame() {
        if (connectedPlayers.size < 2) {
            onError("Need at least 2 players to start")
            return
        }
        
        gameStarted = true
        
        // Initialize the game
        game?.let {
            it.startGame()
            
            // Broadcast game start message
            val message = NetworkProtocol.createGameStartMessage(connectedPlayers.size)
            networkManager?.sendData(message)
            
            // Broadcast initial game state
            broadcastGameState()
            
            // Start ping timer to maintain connections
            startPingTimer()
        }
    }
    
    /**
     * Starts a timer to send ping messages to clients
     */
    private fun startPingTimer() {
        pingTimer?.cancel()
        
        pingTimer = Timer().apply {
            scheduleAtFixedRate(object : TimerTask() {
                override fun run() {
                    val pingMessage = NetworkProtocol.createPingMessage()
                    networkManager?.sendData(pingMessage)
                }
            }, PING_INTERVAL, PING_INTERVAL)
        }
    }
    
    /**
     * Gets the host player's ID
     */
    fun getHostPlayerId(): Int {
        return hostPlayerId
    }
    
    /**
     * Cleans up resources when the server is destroyed
     */
    fun cleanup() {
        pingTimer?.cancel()
        pingTimer = null
        
        networkManager?.cleanup()
        networkManager = null
    }
}