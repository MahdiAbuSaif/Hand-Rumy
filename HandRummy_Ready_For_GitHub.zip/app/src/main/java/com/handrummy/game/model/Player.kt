package com.handrummy.game.model

import java.io.Serializable

/**
 * Represents a player in the Hand Rummy game.
 */
class Player(val id: Int, val name: String = "Player $id") : Serializable {
    
    // The player's hand of cards
    val hand = mutableListOf<Card>()
    
    // The melds that the player has declared
    val declaredMelds = mutableListOf<Meld>()
    
    // Whether the player has initially laid down cards (must meet minimum score of 51)
    private var hasLaidInitialMelds = false
    
    // Whether the player is ready (in lobby)
    var isReady = false
    
    /**
     * Add a card to the player's hand
     */
    fun addCardToHand(card: Card) {
        hand.add(card)
        // Sort hand for better display
        hand.sortWith(compareBy({ it.suit }, { it.rank }))
    }
    
    /**
     * Remove a card from the player's hand
     */
    fun removeCardFromHand(card: Card): Boolean {
        return hand.remove(card)
    }
    
    /**
     * Get a card from the player's hand by its ID
     */
    fun getCardById(cardId: Int): Card? {
        return hand.find { it.getId() == cardId }
    }
    
    /**
     * Declare a meld (set or run)
     */
    fun declareMeld(meld: Meld): Boolean {
        // Check if the meld is valid
        if (!meld.isValid()) {
            return false
        }
        
        // Check if player has all the required cards in hand
        for (card in meld.cards) {
            if (!hand.contains(card)) {
                return false
            }
        }
        
        // Check initial meld score requirement of 51+ points
        if (!hasLaidInitialMelds) {
            val totalMeldScore = meld.getScore()
            if (totalMeldScore < 51) {
                return false // Initial melds must have a total score of at least 51
            }
            hasLaidInitialMelds = true
        }
        
        // Add meld to declared melds
        declaredMelds.add(meld)
        
        // Remove cards from hand
        for (card in meld.cards) {
            hand.remove(card)
        }
        
        return true
    }
    
    /**
     * Create a set meld with cards of the same rank
     */
    fun createSetMeld(rank: Int): Meld? {
        val cardsOfRank = hand.filter { it.rank == rank }
        if (cardsOfRank.size < 3) {
            return null // Need at least 3 cards for a set
        }
        
        val meld = Meld(Meld.TYPE_SET)
        for (card in cardsOfRank) {
            meld.addCard(card)
        }
        
        // Check if the meld is valid and meets initial requirement (if needed)
        if (!meld.isValid() || (!hasLaidInitialMelds && meld.getScore() < 51)) {
            return null
        }
        
        return meld
    }
    
    /**
     * Create a run meld with consecutive cards of the same suit
     */
    fun createRunMeld(selectedCards: List<Card>): Meld? {
        if (selectedCards.size < 3) {
            return null // Need at least 3 cards for a run
        }
        
        // Check if all cards are the same suit
        val suit = selectedCards[0].suit
        if (selectedCards.any { it.suit != suit && !it.isJoker() }) {
            return null
        }
        
        // Sort cards by rank
        val sortedCards = selectedCards.sortedBy { it.rank }
        
        // Create a meld and add cards
        val meld = Meld(Meld.TYPE_RUN)
        for (card in sortedCards) {
            meld.addCard(card)
        }
        
        // Check if the meld is valid and meets initial requirement (if needed)
        if (!meld.isValid() || (!hasLaidInitialMelds && meld.getScore() < 51)) {
            return null
        }
        
        return meld
    }
    
    /**
     * Add a card to an existing meld
     */
    fun addCardToMeld(meldIndex: Int, card: Card): Boolean {
        if (meldIndex < 0 || meldIndex >= declaredMelds.size) {
            return false
        }
        
        // Check if player has the card in hand
        if (!hand.contains(card)) {
            return false
        }
        
        // Try to add the card to the meld
        val meld = declaredMelds[meldIndex]
        if (meld.addCard(card)) {
            hand.remove(card)
            return true
        }
        
        return false
    }
    
    /**
     * Check if the player has a valid rummy (no cards left in hand)
     */
    fun hasRummy(): Boolean {
        return hand.isEmpty() && declaredMelds.isNotEmpty()
    }
    
    /**
     * Calculate the player's score (total value of cards in hand)
     */
    fun getHandScore(): Int {
        return hand.sumOf { it.getValue() }
    }
    
    /**
     * Get the total score of all melds
     */
    fun getMeldsScore(): Int {
        return declaredMelds.sumOf { it.getScore() }
    }

    /**
     * Check if player has laid down the initial melds
     */
    fun hasLaidDown(): Boolean {
        return hasLaidInitialMelds
    }
    
    /**
     * Check total value of cards in hand
     */
    fun getHandValue(): Int {
        return hand.sumOf { it.getValue() }
    }
    
    /**
     * Serialize the player to a string
     */
    fun serialize(): String {
        val sb = StringBuilder()
        
        // Serialize basic info
        sb.append("$id|$name|$isReady|$hasLaidInitialMelds")
        
        // Serialize hand
        sb.append("|${hand.size}")
        for (card in hand) {
            sb.append(";${card.serialize()}")
        }
        
        // Serialize melds
        sb.append("|${declaredMelds.size}")
        for (meld in declaredMelds) {
            sb.append(";${meld.serialize()}")
        }
        
        return sb.toString()
    }
    
    /**
     * Create a player from a serialized string
     */
    companion object {
        fun fromString(serialized: String): Player {
            val parts = serialized.split("|")
            if (parts.size < 5) {
                throw IllegalArgumentException("Invalid player format: $serialized")
            }
            
            val id = parts[0].toInt()
            val name = parts[1]
            val isReady = parts[2].toBoolean()
            val hasLaidInitialMelds = parts[3].toBoolean()
            
            val player = Player(id, name)
            player.isReady = isReady
            player.hasLaidInitialMelds = hasLaidInitialMelds
            
            // Deserialize hand
            val handParts = parts[4].split(";")
            val handSize = handParts[0].toInt()
            for (i in 1..handSize) {
                player.hand.add(Card.fromString(handParts[i]))
            }
            
            // Deserialize melds
            if (parts.size > 5) {
                val meldParts = parts[5].split(";")
                val meldSize = meldParts[0].toInt()
                for (i in 1..meldSize) {
                    player.declaredMelds.add(Meld.fromString(meldParts[i]))
                }
            }
            
            return player
        }
    }
}