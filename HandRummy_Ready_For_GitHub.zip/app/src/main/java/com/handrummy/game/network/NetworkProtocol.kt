package com.handrummy.game.network

/**
 * Protocol constants and definitions for network communication in Hand Rummy game.
 */
object NetworkProtocol {
    
    /**
     * Message types for communication between host and clients
     */
    object MessageType {
        // Connection messages
        const val CONNECT_REQUEST = "CONNECT_REQUEST"
        const val CONNECT_ACCEPT = "CONNECT_ACCEPT"
        const val CONNECT_REJECT = "CONNECT_REJECT"
        
        // Lobby messages
        const val PLAYER_JOIN = "PLAYER_JOIN"
        const val PLAYER_LEAVE = "PLAYER_LEAVE"
        const val PLAYER_READY = "PLAYER_READY"
        const val GAME_START = "GAME_START"
        
        // Game state messages
        const val GAME_STATE = "GAME_STATE"
        const val GAME_STATE_REQUEST = "GAME_STATE_REQUEST"
        const val GAME_ACTION = "GAME_ACTION"
        const val GAME_OVER = "GAME_OVER"
        
        // Chat messages
        const val CHAT_MESSAGE = "CHAT_MESSAGE"
        
        // Error messages
        const val ERROR = "ERROR"
    }
    
    /**
     * Game actions
     */
    object Action {
        const val DRAW_FROM_DECK = "DRAW_FROM_DECK"
        const val DRAW_FROM_DISCARD = "DRAW_FROM_DISCARD"
        const val DISCARD = "DISCARD"
        const val DECLARE_MELD = "DECLARE_MELD"
        const val ADD_TO_MELD = "ADD_TO_MELD"
        const val DECLARE_RUMMY = "DECLARE_RUMMY"
    }
    
    /**
     * Error codes
     */
    object ErrorCode {
        const val INVALID_ACTION = "INVALID_ACTION"
        const val NOT_YOUR_TURN = "NOT_YOUR_TURN"
        const val GAME_FULL = "GAME_FULL"
        const val INVALID_STATE = "INVALID_STATE"
    }
    
    /**
     * Format a message for network transmission
     */
    fun formatMessage(type: String, data: String = ""): String {
        return "$type:$data"
    }
    
    /**
     * Parse a message received from the network
     */
    fun parseMessage(message: String): Pair<String, String> {
        val parts = message.split(":", limit = 2)
        if (parts.size < 2) {
            return Pair(parts[0], "")
        }
        
        return Pair(parts[0], parts[1])
    }
    
    /**
     * Format a game action message
     */
    fun formatGameAction(playerId: Int, action: String, data: String = ""): String {
        return "$playerId|$action|$data"
    }
    
    /**
     * Parse a game action message
     */
    fun parseGameAction(data: String): Triple<Int, String, String> {
        val parts = data.split("|", limit = 3)
        if (parts.size < 3) {
            return Triple(parts[0].toInt(), parts[1], "")
        }
        
        return Triple(parts[0].toInt(), parts[1], parts[2])
    }
}