package com.handrummy.game.network

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.app.ActivityCompat
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/**
 * Manages Bluetooth connections for the Hand Rummy game.
 * Handles device discovery, connection establishment, and data transfer.
 */
class BluetoothManager(
    private val context: Context,
    private val onDeviceFound: (BluetoothDevice) -> Unit,
    private val onConnectionSuccess: () -> Unit,
    private val onConnectionFailed: (String) -> Unit
) {

    companion object {
        private const val TAG = "BluetoothManager"
        private val SERVICE_UUID = UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66")
        private const val SERVICE_NAME = "HandRummyGame"
    }
    
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var serverSocket: BluetoothServerSocket? = null
    private var clientSocket: BluetoothSocket? = null
    private var isServerRunning = false
    private var discoveryRunning = false
    
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null
    
    private val handler = Handler(Looper.getMainLooper())
    private val discoveredDevices = mutableListOf<BluetoothDevice>()
    
    // Callback for data received from connected device
    private var onDataReceived: ((String) -> Unit)? = null
    
    // BroadcastReceiver for device discovery
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when(intent.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }
                    
                    device?.let {
                        if (!discoveredDevices.contains(it)) {
                            discoveredDevices.add(it)
                            onDeviceFound(it)
                        }
                    }
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    discoveryRunning = false
                }
            }
        }
    }
    
    init {
        // Register for broadcasts when a device is discovered
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        }
        context.registerReceiver(receiver, filter)
    }
    
    /**
     * Checks if Bluetooth is available and enabled on this device
     * 
     * @return True if Bluetooth is available and enabled, false otherwise
     */
    fun isBluetoothAvailable(): Boolean {
        return bluetoothAdapter != null && bluetoothAdapter.isEnabled
    }
    
    /**
     * Makes this device discoverable to other Bluetooth devices
     */
    fun makeDiscoverable() {
        if (bluetoothAdapter == null) {
            onConnectionFailed("Bluetooth not supported on this device")
            return
        }
        
        // Start server to listen for connections
        startServer()
    }
    
    /**
     * Starts discovering nearby Bluetooth devices
     */
    fun discoverDevices() {
        if (bluetoothAdapter == null) {
            onConnectionFailed("Bluetooth not supported on this device")
            return
        }
        
        // Check for necessary permissions on Android 12+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) 
                    != PackageManager.PERMISSION_GRANTED) {
                onConnectionFailed("Bluetooth scan permission not granted")
                return
            }
        }
        
        // Clear previously discovered devices
        discoveredDevices.clear()
        
        // Cancel any ongoing discovery
        if (bluetoothAdapter.isDiscovering) {
            bluetoothAdapter.cancelDiscovery()
        }
        
        // Start discovery
        discoveryRunning = bluetoothAdapter.startDiscovery()
        if (!discoveryRunning) {
            onConnectionFailed("Failed to start device discovery")
        }
    }
    
    /**
     * Connects to a specific Bluetooth device
     * 
     * @param device The Bluetooth device to connect to
     */
    fun connectToDevice(device: BluetoothDevice) {
        if (bluetoothAdapter == null) {
            onConnectionFailed("Bluetooth not supported on this device")
            return
        }
        
        // Cancel discovery because it's resource intensive
        if (bluetoothAdapter.isDiscovering) {
            bluetoothAdapter.cancelDiscovery()
        }
        
        // Check for necessary permissions on Android 12+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) 
                    != PackageManager.PERMISSION_GRANTED) {
                onConnectionFailed("Bluetooth connect permission not granted")
                return
            }
        }
        
        // Connect to the device
        Thread {
            try {
                // Create RFCOMM socket
                clientSocket = device.createRfcommSocketToServiceRecord(SERVICE_UUID)
                
                // Connect to the remote device
                clientSocket?.connect()
                
                // Get the input and output streams
                inputStream = clientSocket?.inputStream
                outputStream = clientSocket?.outputStream
                
                // Start listening for incoming data
                startDataListener()
                
                // Connection successful
                handler.post {
                    onConnectionSuccess()
                }
            } catch (e: IOException) {
                // Close the socket
                try {
                    clientSocket?.close()
                } catch (ce: IOException) {
                    Log.e(TAG, "Error closing client socket: ${ce.message}")
                }
                
                // Report failure
                handler.post {
                    onConnectionFailed("Failed to connect: ${e.message}")
                }
            }
        }.start()
    }
    
    /**
     * Starts a Bluetooth server to accept incoming connections
     */
    private fun startServer() {
        if (bluetoothAdapter == null) {
            onConnectionFailed("Bluetooth not supported on this device")
            return
        }
        
        // Check for necessary permissions on Android 12+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) 
                    != PackageManager.PERMISSION_GRANTED) {
                onConnectionFailed("Bluetooth connect permission not granted")
                return
            }
        }
        
        // Start server thread
        Thread {
            try {
                // Create a server socket
                serverSocket = bluetoothAdapter.listenUsingRfcommWithServiceRecord(
                    SERVICE_NAME, SERVICE_UUID)
                
                isServerRunning = true
                
                // Wait for a connection
                while (isServerRunning) {
                    try {
                        // This call blocks until a connection is accepted or an exception occurs
                        clientSocket = serverSocket?.accept()
                        
                        // A connection was accepted
                        if (clientSocket != null) {
                            // Get the input and output streams
                            inputStream = clientSocket?.inputStream
                            outputStream = clientSocket?.outputStream
                            
                            // Start listening for incoming data
                            startDataListener()
                            
                            // Connection successful
                            handler.post {
                                onConnectionSuccess()
                            }
                            
                            break
                        }
                    } catch (e: IOException) {
                        if (isServerRunning) {
                            Log.e(TAG, "Error accepting connection: ${e.message}")
                        }
                    }
                }
                
                // Close the server socket as we only need one connection
                serverSocket?.close()
                
            } catch (e: IOException) {
                Log.e(TAG, "Error starting server: ${e.message}")
                handler.post {
                    onConnectionFailed("Failed to start server: ${e.message}")
                }
            }
        }.start()
    }
    
    /**
     * Sends data to the connected device
     * 
     * @param data The string data to send
     * @return True if the data was sent successfully, false otherwise
     */
    fun sendData(data: String): Boolean {
        if (outputStream == null) {
            return false
        }
        
        return try {
            outputStream?.write(data.toByteArray())
            true
        } catch (e: IOException) {
            Log.e(TAG, "Error sending data: ${e.message}")
            false
        }
    }
    
    /**
     * Sets the callback for receiving data from the connected device
     * 
     * @param callback The function to call when data is received
     */
    fun setOnDataReceivedListener(callback: (String) -> Unit) {
        onDataReceived = callback
    }
    
    /**
     * Starts listening for incoming data from the connected device
     */
    private fun startDataListener() {
        Thread {
            val buffer = ByteArray(1024)
            var bytes: Int
            
            // Keep listening to the InputStream
            while (true) {
                try {
                    // Read from the InputStream
                    bytes = inputStream?.read(buffer) ?: -1
                    
                    if (bytes > 0) {
                        // Convert to string
                        val data = String(buffer, 0, bytes)
                        
                        // Call the callback
                        handler.post {
                            onDataReceived?.invoke(data)
                        }
                    }
                } catch (e: IOException) {
                    Log.e(TAG, "Error reading data: ${e.message}")
                    break
                }
            }
        }.start()
    }
    
    /**
     * Cleans up Bluetooth resources
     */
    fun cleanup() {
        // Unregister broadcast receiver
        try {
            context.unregisterReceiver(receiver)
        } catch (e: IllegalArgumentException) {
            // Receiver not registered
        }
        
        // Cancel discovery if running
        if (bluetoothAdapter?.isDiscovering == true) {
            bluetoothAdapter.cancelDiscovery()
        }
        
        // Stop server
        isServerRunning = false
        
        // Close server socket
        try {
            serverSocket?.close()
        } catch (e: IOException) {
            Log.e(TAG, "Error closing server socket: ${e.message}")
        }
        
        // Close client socket
        try {
            clientSocket?.close()
        } catch (e: IOException) {
            Log.e(TAG, "Error closing client socket: ${e.message}")
        }
        
        // Close streams
        try {
            inputStream?.close()
            outputStream?.close()
        } catch (e: IOException) {
            Log.e(TAG, "Error closing streams: ${e.message}")
        }
    }
}
