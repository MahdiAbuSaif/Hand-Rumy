package com.handrummy.game

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.handrummy.game.model.Card
import com.handrummy.game.model.Game
import com.handrummy.game.model.Meld
import com.handrummy.game.model.Player
import com.handrummy.game.network.GameClient
import com.handrummy.game.network.GameServer
import com.handrummy.game.network.NetworkManager
import com.handrummy.game.network.NetworkProtocol
import com.handrummy.game.ui.CardView
import com.handrummy.game.ui.GameBoardView
import com.handrummy.game.ui.PlayerHandView

class GameActivity : BaseActivity() {

    // UI components
    private lateinit var gameBoardView: GameBoardView
    private lateinit var playerHandView: PlayerHandView
    private lateinit var drawPileButton: Button
    private lateinit var discardPileButton: Button
    private lateinit var declareRummyButton: Button
    private lateinit var playerTurnTextView: TextView
    private lateinit var cardsRemainingTextView: TextView
    private lateinit var selectedCardTextView: TextView

    // Game components
    private var isHost = false
    private var gameServer: GameServer? = null
    private var gameClient: GameClient? = null
    private var game: Game? = null
    private var localPlayerId = -1
    private var selectedCard: Card? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        // Get intent data
        isHost = intent.getBooleanExtra("IS_HOST", false)

        // Initialize UI components
        initializeViews()
        setupListeners()

        // Get connection type from preferences
        val sharedPrefs = getSharedPreferences("HandRummyPrefs", MODE_PRIVATE)
        val connectionTypeValue = sharedPrefs.getInt("CONNECTION_TYPE", 0)
        val connectionType = if (connectionTypeValue == 1) 
                            NetworkManager.ConnectionType.WIFI_DIRECT 
                         else 
                            NetworkManager.ConnectionType.BLUETOOTH

        // Initialize game components based on host status
        if (isHost) {
            // Get game server reference from LobbyActivity
            gameServer = (application as? Application)?.gameServer
            if (gameServer == null) {
                showErrorAndFinish("Game server not available")
                return
            }

            localPlayerId = gameServer?.getHostPlayerId() ?: 0
            
            // Set game state listener
            gameServer?.setOnGameStateUpdatedListener { updatedGame ->
                game = updatedGame
                updateUI()
            }
        } else {
            // Get game client reference from LobbyActivity
            gameClient = (application as? Application)?.gameClient
            if (gameClient == null) {
                showErrorAndFinish("Game client not available")
                return
            }

            localPlayerId = gameClient?.getPlayerId() ?: -1
            if (localPlayerId == -1) {
                showErrorAndFinish("Invalid player ID")
                return
            }

            // Set game state listener
            gameClient?.setOnGameStateUpdatedListener { updatedGame ->
                game = updatedGame
                updateUI()
            }

            // Request initial game state
            gameClient?.requestGameState()
        }
    }

    private fun initializeViews() {
        gameBoardView = findViewById(R.id.gameBoardView)
        playerHandView = findViewById(R.id.playerHandView)
        drawPileButton = findViewById(R.id.drawPileButton)
        discardPileButton = findViewById(R.id.discardPileButton)
        declareRummyButton = findViewById(R.id.declareRummyButton)
        playerTurnTextView = findViewById(R.id.playerTurnTextView)
        cardsRemainingTextView = findViewById(R.id.cardsRemainingTextView)
        selectedCardTextView = findViewById(R.id.selectedCardTextView)
    }

    private fun setupListeners() {
        // Draw pile button - draw a card from the deck
        drawPileButton.setOnClickListener {
            if (!isMyTurn()) {
                Toast.makeText(this, getString(R.string.waiting_for_turn), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (game?.currentPlayerHasDrawn() == true) {
                Toast.makeText(this, "You've already drawn a card this turn", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            performAction(NetworkProtocol.Action.DRAW_FROM_DECK)
        }

        // Discard pile button - draw a card from the discard pile or discard a card
        discardPileButton.setOnClickListener {
            if (!isMyTurn()) {
                Toast.makeText(this, getString(R.string.waiting_for_turn), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (game?.currentPlayerHasDrawn() == false) {
                // Player hasn't drawn yet, so they can draw from discard pile
                performAction(NetworkProtocol.Action.DRAW_FROM_DISCARD)
            } else if (selectedCard != null) {
                // Player has drawn and selected a card, so they can discard it
                performAction(NetworkProtocol.Action.DISCARD, selectedCard!!.serialize())
                selectedCard = null
                selectedCardTextView.text = ""
            } else {
                Toast.makeText(this, "Select a card to discard", Toast.LENGTH_SHORT).show()
            }
        }

        // Declare rummy button - declare that you have a valid rummy
        declareRummyButton.setOnClickListener {
            if (!isMyTurn()) {
                Toast.makeText(this, getString(R.string.waiting_for_turn), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Check if player has a valid rummy (no cards in hand)
            val localPlayer = game?.getPlayerById(localPlayerId)
            if (localPlayer?.hasRummy() == true) {
                performAction(NetworkProtocol.Action.DECLARE_RUMMY, localPlayerId.toString())
            } else {
                // Check if player has laid down initial melds
                if (!localPlayer?.hasLaidDown()!!) {
                    Toast.makeText(this, getString(R.string.need_initial_melds), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, getString(R.string.invalid_rummy), Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Setup card selection listener
        playerHandView.setOnCardSelectedListener { card ->
            selectedCard = card
            selectedCardTextView.text = "Selected: ${card.getShortName()}"

            // Show options for the selected card
            showCardOptionsDialog(card)
        }
    }

    private fun showCardOptionsDialog(card: Card) {
        val options = arrayOf("Discard", "Form Set", "Form Run", "Cancel")
        
        AlertDialog.Builder(this)
            .setTitle("Card Options")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> { // Discard
                        if (isMyTurn() && game?.currentPlayerHasDrawn() == true) {
                            performAction(NetworkProtocol.Action.DISCARD, card.serialize())
                            selectedCard = null
                            selectedCardTextView.text = ""
                        } else {
                            Toast.makeText(this, "You must draw a card first", Toast.LENGTH_SHORT).show()
                        }
                    }
                    1 -> { // Form Set
                        attemptToFormSet(card)
                    }
                    2 -> { // Form Run
                        attemptToFormRun(card)
                    }
                    3 -> { // Cancel
                        selectedCard = null
                        selectedCardTextView.text = ""
                    }
                }
            }
            .show()
    }

    private fun attemptToFormSet(card: Card) {
        val localPlayer = game?.getPlayerById(localPlayerId) ?: return
        
        // Try to form a set with the selected card
        val meld = localPlayer.createSetMeld(card.rank)
        
        if (meld != null) {
            performAction(NetworkProtocol.Action.DECLARE_MELD, meld.serialize())
        } else {
            Toast.makeText(this, "Cannot form a set with this card", Toast.LENGTH_SHORT).show()
        }
    }

    private fun attemptToFormRun(card: Card) {
        // This would require a more complex UI to select multiple cards for a run
        // For now, we'll just show a message
        Toast.makeText(this, "Run formation requires selecting multiple cards - not implemented yet", Toast.LENGTH_SHORT).show()
    }

    private fun isMyTurn(): Boolean {
        return game?.getCurrentPlayerId() == localPlayerId
    }

    private fun performAction(action: String, data: String = "") {
        if (isHost) {
            // If host, update game directly
            gameServer?.processPlayerAction(localPlayerId, action, data)
        } else {
            // If client, send action to server
            gameClient?.performAction(action, data)
        }
    }

    private fun updateUI() {
        runOnUiThread {
            game?.let { currentGame ->
                // Update player hand
                val localPlayer = currentGame.getPlayerById(localPlayerId)
                localPlayer?.let {
                    playerHandView.setCards(it.hand)
                }
                
                // Update game board
                gameBoardView.setGame(currentGame)
                
                // Update turn indicator
                if (isMyTurn()) {
                    playerTurnTextView.text = getString(R.string.your_turn)
                    playerTurnTextView.setTextColor(getColor(R.color.playerActiveHighlight))
                } else {
                    val currentPlayerId = currentGame.getCurrentPlayerId()
                    playerTurnTextView.text = getString(R.string.player_turn, currentPlayerId)
                    playerTurnTextView.setTextColor(getColor(R.color.colorText))
                }
                
                // Update cards remaining
                val cardsRemaining = currentGame.getDeck().getCardCount()
                cardsRemainingTextView.text = getString(R.string.cards_remaining, cardsRemaining)
                
                // Update discard pile button text
                val topDiscard = currentGame.getTopDiscard()
                if (topDiscard != null) {
                    discardPileButton.text = "${getString(R.string.discard_pile)}: ${topDiscard.getShortName()}"
                } else {
                    discardPileButton.text = getString(R.string.discard_pile)
                }
                
                // Enable/disable buttons based on game state
                updateButtonStates()
            }
        }
    }

    private fun updateButtonStates() {
        val isMyTurn = isMyTurn()
        val hasDrawn = game?.currentPlayerHasDrawn() == true
        
        // Draw buttons only enabled if it's your turn and you haven't drawn yet
        drawPileButton.isEnabled = isMyTurn && !hasDrawn
        
        // Discard pile button enabled if:
        // 1. It's your turn and you haven't drawn (can draw from discard)
        // 2. It's your turn, you have drawn, and selected a card (can discard)
        discardPileButton.isEnabled = isMyTurn && (!hasDrawn || selectedCard != null)
        
        // Declare rummy button only enabled if it's your turn
        declareRummyButton.isEnabled = isMyTurn
    }

    private fun showErrorAndFinish(message: String) {
        AlertDialog.Builder(this)
            .setTitle("Error")
            .setMessage(message)
            .setPositiveButton("OK") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Cleanup resources
    }
}