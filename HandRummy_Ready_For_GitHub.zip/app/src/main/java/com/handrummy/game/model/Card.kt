package com.handrummy.game.model

import java.io.Serializable

/**
 * Represents a playing card in the Hand Rummy game.
 */
class Card(val suit: Int, val rank: Int) : Serializable, Comparable<Card> {
    
    companion object {
        // Suits
        const val SUIT_HEARTS = 0
        const val SUIT_DIAMONDS = 1
        const val SUIT_CLUBS = 2
        const val SUIT_SPADES = 3
        
        // Special ranks
        const val RANK_ACE = 1
        const val RANK_JACK = 11
        const val RANK_QUEEN = 12
        const val RANK_KING = 13
        
        // Joker
        const val RANK_JOKER = 0
        const val SUIT_JOKER = 4
        
        /**
         * Create a card from a serialized string
         */
        fun fromString(serialized: String): Card {
            val parts = serialized.split(":")
            if (parts.size != 2) {
                throw IllegalArgumentException("Invalid card format: $serialized")
            }
            
            return Card(parts[0].toInt(), parts[1].toInt())
        }
    }

    /**
     * Get the value of the card
     */
    fun getValue(): Int {
        return when (rank) {
            RANK_ACE -> 1
            RANK_JACK, RANK_QUEEN, RANK_KING -> 10
            else -> rank
        }
    }
    
    /**
     * Get the short name of the card (e.g. "A♥", "10♠")
     */
    fun getShortName(): String {
        val rankString = when (rank) {
            RANK_ACE -> "A"
            RANK_JACK -> "J"
            RANK_QUEEN -> "Q"
            RANK_KING -> "K"
            RANK_JOKER -> "*"
            else -> rank.toString()
        }
        
        val suitString = when (suit) {
            SUIT_HEARTS -> "♥"
            SUIT_DIAMONDS -> "♦"
            SUIT_CLUBS -> "♣"
            SUIT_SPADES -> "♠"
            else -> ""
        }
        
        return "$rankString$suitString"
    }
    
    /**
     * Check if this card is a joker
     */
    fun isJoker(): Boolean {
        return suit == SUIT_JOKER && rank == RANK_JOKER
    }
    
    /**
     * Get a unique identifier for this card
     */
    fun getId(): Int {
        return suit * 13 + rank
    }
    
    /**
     * Serialize the card to a string
     */
    fun serialize(): String {
        return "$suit:$rank"
    }
    
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Card) return false
        
        return suit == other.suit && rank == other.rank
    }
    
    override fun hashCode(): Int {
        return 31 * suit + rank
    }
    
    override fun toString(): String {
        return getShortName()
    }
    
    /**
     * Compare cards based on rank and suit
     */
    override fun compareTo(other: Card): Int {
        // First compare by rank
        val rankComparison = rank.compareTo(other.rank)
        if (rankComparison != 0) {
            return rankComparison
        }
        
        // If ranks are equal, compare by suit
        return suit.compareTo(other.suit)
    }
}