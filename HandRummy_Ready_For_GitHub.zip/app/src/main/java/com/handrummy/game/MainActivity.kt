package com.handrummy.game

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.content.DialogInterface
import android.widget.ImageButton
import com.handrummy.game.utils.LocaleHelper

class MainActivity : BaseActivity() {

    private val PERMISSIONS_REQUEST_CODE = 100
    private val requiredPermissions = arrayOf(
        Manifest.permission.BLUETOOTH,
        Manifest.permission.BLUETOOTH_ADMIN,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_WIFI_STATE,
        Manifest.permission.CHANGE_WIFI_STATE,
        Manifest.permission.ACCESS_NETWORK_STATE,
        Manifest.permission.CHANGE_NETWORK_STATE
    )
    
    // Add Bluetooth permissions for Android 12+
    private val requiredBluetoothPermissionsAndroid12 = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT
        )
    } else {
        arrayOf()
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        val titleTextView = findViewById<TextView>(R.id.titleTextView)
        val createGameButton = findViewById<Button>(R.id.createGameButton)
        val joinGameButton = findViewById<Button>(R.id.joinGameButton)
        val rulesButton = findViewById<Button>(R.id.rulesButton)
        val languageButton = findViewById<Button>(R.id.languageButton)
        
        // Check and request permissions
        checkAndRequestPermissions()
        
        createGameButton.setOnClickListener {
            val intent = Intent(this, ConnectionActivity::class.java)
            intent.putExtra("IS_HOST", true)
            startActivity(intent)
        }
        
        joinGameButton.setOnClickListener {
            val intent = Intent(this, ConnectionActivity::class.java)
            intent.putExtra("IS_HOST", false)
            startActivity(intent)
        }
        
        rulesButton.setOnClickListener {
            showRulesDialog()
        }
        
        languageButton.setOnClickListener {
            showLanguageSelectionDialog()
        }
    }
    
    /**
     * Shows a dialog to select app language
     */
    private fun showLanguageSelectionDialog() {
        val languages = arrayOf("English", "العربية")
        val languageCodes = arrayOf("en", "ar")
        
        val currentLanguage = LocaleHelper.getPersistedLanguage(this)
        val currentIndex = when (currentLanguage) {
            "ar" -> 1
            else -> 0 // Default to English
        }
        
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.select_language))
            .setSingleChoiceItems(languages, currentIndex) { dialogInterface: DialogInterface, position: Int ->
                // Change language
                val context = LocaleHelper.setLocale(this, languageCodes[position])
                
                // Restart activity to apply changes
                dialogInterface.dismiss()
                recreate()
            }
            .setNegativeButton(getString(R.string.ok), null)
            .show()
    }
    
    private fun checkAndRequestPermissions() {
        val permissionsToRequest = ArrayList<String>()
        
        // Check each permission
        for (permission in requiredPermissions + requiredBluetoothPermissionsAndroid12) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission)
            }
        }
        
        // Request permissions if needed
        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissionsToRequest.toTypedArray(),
                PERMISSIONS_REQUEST_CODE
            )
        }
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        
        if (requestCode == PERMISSIONS_REQUEST_CODE) {
            var allGranted = true
            for (result in grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false
                    break
                }
            }
            
            if (!allGranted) {
                // Some permissions were denied
                // Show message to user explaining why permissions are needed
                showPermissionDeniedDialog()
            }
        }
    }
    
    private fun showPermissionDeniedDialog() {
        // Show dialog explaining why permissions are needed
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.permissions_required))
            .setMessage(getString(R.string.permissions_required_message))
            .setPositiveButton(getString(R.string.retry)) { _, _ ->
                checkAndRequestPermissions()
            }
            .setNegativeButton(getString(R.string.exit)) { _, _ ->
                finish()
            }
            .setCancelable(false)
            .show()
    }
    
    private fun showRulesDialog() {
        // Show dialog with Hand Rummy rules
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.game_rules))
            .setMessage(getString(R.string.rummy_rules_text))
            .setPositiveButton(getString(R.string.ok), null)
            .show()
    }
}
