package com.handrummy.game.utils

import android.content.Context
import android.graphics.Color
import androidx.core.content.ContextCompat
import com.handrummy.game.R
import com.handrummy.game.model.Card

/**
 * Utility class for card-related operations.
 */
object CardUtils {

    /**
     * Gets the background color for a card based on its suit
     * 
     * @param context The Android context
     * @param card The card
     * @return The color resource for the card's background
     */
    fun getCardBackgroundColor(context: Context, card: Card): Int {
        return ContextCompat.getColor(context, R.color.cardBackground)
    }
    
    /**
     * Gets the text color for a card based on its suit
     * 
     * @param context The Android context
     * @param card The card
     * @return The color for the card's text
     */
    fun getCardTextColor(context: Context, card: Card): Int {
        return when (card.suit) {
            Card.HEARTS, Card.DIAMONDS -> ContextCompat.getColor(context, R.color.cardRed)
            else -> ContextCompat.getColor(context, R.color.cardBlack)
        }
    }
    
    /**
     * Gets the suit symbol for a card
     * 
     * @param card The card
     * @return The Unicode symbol for the card's suit
     */
    fun getSuitSymbol(card: Card): String {
        return when (card.suit) {
            Card.SPADES -> "♠"
            Card.HEARTS -> "♥"
            Card.DIAMONDS -> "♦"
            Card.CLUBS -> "♣"
            else -> "?"
        }
    }
    
    /**
     * Gets the rank display text for a card
     * 
     * @param card The card
     * @return The display text for the card's rank
     */
    fun getRankDisplay(card: Card): String {
        return when (card.rank) {
            Card.ACE -> "A"
            Card.JACK -> "J"
            Card.QUEEN -> "Q"
            Card.KING -> "K"
            else -> card.rank.toString()
        }
    }
    
    /**
     * Checks if a set of cards forms a valid meld in Hand Rummy
     * 
     * @param cards The list of cards to check
     * @return True if the cards form a valid meld, false otherwise
     */
    fun isValidMeld(cards: List<Card>): Boolean {
        if (cards.size < 3) {
            return false
        }
        
        // Check if it's a set (same rank, different suits)
        if (isValidSet(cards)) {
            return true
        }
        
        // Check if it's a run (consecutive ranks, same suit)
        if (isValidRun(cards)) {
            return true
        }
        
        return false
    }
    
    /**
     * Checks if a set of cards forms a valid set (same rank, different suits)
     * 
     * @param cards The list of cards to check
     * @return True if the cards form a valid set, false otherwise
     */
    fun isValidSet(cards: List<Card>): Boolean {
        if (cards.size < 3) {
            return false
        }
        
        // All cards must have the same rank
        val rank = cards[0].rank
        if (!cards.all { it.rank == rank }) {
            return false
        }
        
        // All cards must have different suits
        val suits = cards.map { it.suit }.distinct()
        return suits.size == cards.size
    }
    
    /**
     * Checks if a set of cards forms a valid run (consecutive ranks, same suit)
     * 
     * @param cards The list of cards to check
     * @return True if the cards form a valid run, false otherwise
     */
    fun isValidRun(cards: List<Card>): Boolean {
        if (cards.size < 3) {
            return false
        }
        
        // All cards must have the same suit
        val suit = cards[0].suit
        if (!cards.all { it.suit == suit }) {
            return false
        }
        
        // Sort cards by rank
        val sortedCards = cards.sortedBy { it.rank }
        
        // Check that ranks are consecutive
        for (i in 0 until sortedCards.size - 1) {
            if (sortedCards[i + 1].rank != sortedCards[i].rank + 1) {
                return false
            }
        }
        
        return true
    }
    
    /**
     * Sorts a list of cards by suit and rank
     * 
     * @param cards The list of cards to sort
     * @return The sorted list of cards
     */
    fun sortCards(cards: List<Card>): List<Card> {
        return cards.sortedWith(compareBy({ it.suit }, { it.rank }))
    }
}
