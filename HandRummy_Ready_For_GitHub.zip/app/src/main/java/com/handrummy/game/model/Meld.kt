package com.handrummy.game.model

import java.io.Serializable

/**
 * Represents a meld (a valid combination of cards) in the Hand Rummy game.
 * A meld can be either a set (cards of the same rank but different suits)
 * or a run (consecutive cards of the same suit).
 */
class Meld(val type: Int, val cards: MutableList<Card> = mutableListOf()) : Serializable {
    
    companion object {
        const val TYPE_SET = 0 // Cards of the same rank (e.g., three 5s)
        const val TYPE_RUN = 1 // Cards in sequence of the same suit (e.g., 5♥, 6♥, 7♥)
        
        /**
         * Create a meld from a serialized string
         */
        fun fromString(serialized: String): Meld {
            val parts = serialized.split("|")
            if (parts.size < 2) {
                throw IllegalArgumentException("Invalid meld format: $serialized")
            }
            
            val type = parts[0].toInt()
            val meld = Meld(type)
            
            for (i in 1 until parts.size) {
                meld.cards.add(Card.fromString(parts[i]))
            }
            
            return meld
        }
    }
    
    /**
     * Add a card to this meld
     */
    fun addCard(card: Card): Boolean {
        // Check if the card can be added to this meld
        if (isValidAddition(card)) {
            cards.add(card)
            
            // Sort cards if this is a run
            if (type == TYPE_RUN) {
                cards.sortBy { it.rank }
            }
            
            return true
        }
        
        return false
    }
    
    /**
     * Remove a card from this meld
     */
    fun removeCard(card: Card): Boolean {
        return cards.remove(card)
    }
    
    /**
     * Check if a card can be added to this meld
     */
    fun isValidAddition(card: Card): Boolean {
        // Jokers can be added to any meld
        if (card.isJoker()) {
            return true
        }
        
        when (type) {
            TYPE_SET -> {
                // For a set, the rank must match, and the suit must be different
                if (cards.isEmpty()) {
                    return true
                }
                
                val rank = cards[0].rank
                return card.rank == rank && cards.none { it.suit == card.suit }
            }
            
            TYPE_RUN -> {
                // For a run, the suit must match, and the rank must be in sequence
                if (cards.isEmpty()) {
                    return true
                }
                
                val suit = cards[0].suit
                if (card.suit != suit) {
                    return false
                }
                
                // Sort cards by rank
                val sortedCards = cards.sortedBy { it.rank }
                
                // Check if the card fits at the beginning or end of the run
                return (card.rank == sortedCards.first().rank - 1 || 
                        card.rank == sortedCards.last().rank + 1)
            }
            
            else -> return false
        }
    }
    
    /**
     * Check if this meld is valid
     */
    fun isValid(): Boolean {
        // A meld must have at least 3 cards
        if (cards.size < 3) {
            return false
        }
        
        when (type) {
            TYPE_SET -> {
                // All cards must have the same rank and different suits
                val firstRank = cards[0].rank
                val suits = mutableSetOf<Int>()
                
                for (card in cards) {
                    if (card.isJoker()) continue
                    
                    if (card.rank != firstRank) {
                        return false
                    }
                    
                    if (suits.contains(card.suit)) {
                        return false
                    }
                    
                    suits.add(card.suit)
                }
                
                // A set can have at most 4 cards (one of each suit)
                return suits.size <= 4
            }
            
            TYPE_RUN -> {
                // All cards must be of the same suit and in sequence
                val sortedCards = cards.filter { !it.isJoker() }.sortedBy { it.rank }
                if (sortedCards.isEmpty()) return true // All jokers
                
                val firstSuit = sortedCards[0].suit
                
                for (i in 0 until sortedCards.size - 1) {
                    if (sortedCards[i].suit != firstSuit) {
                        return false
                    }
                    
                    // Check for sequence, allowing for gaps that could be filled with jokers
                    val jokerCount = cards.count { it.isJoker() }
                    val gap = sortedCards[i + 1].rank - sortedCards[i].rank - 1
                    
                    if (gap > jokerCount) {
                        return false
                    }
                }
                
                return sortedCards.all { it.suit == firstSuit }
            }
            
            else -> return false
        }
    }
    
    /**
     * Get the score value of this meld
     */
    fun getScore(): Int {
        return cards.sumOf { it.getValue() }
    }
    
    /**
     * Serialize the meld to a string
     */
    fun serialize(): String {
        val sb = StringBuilder()
        sb.append("$type")
        
        for (card in cards) {
            sb.append("|${card.serialize()}")
        }
        
        return sb.toString()
    }
    
    override fun toString(): String {
        val typeString = if (type == TYPE_SET) "Set" else "Run"
        return "$typeString: ${cards.joinToString(", ")}"
    }
}