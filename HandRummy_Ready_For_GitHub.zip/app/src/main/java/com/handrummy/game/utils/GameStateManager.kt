package com.handrummy.game.utils

import android.util.Log
import com.handrummy.game.model.Card
import com.handrummy.game.model.Deck
import com.handrummy.game.model.Game
import com.handrummy.game.model.Meld
import com.handrummy.game.model.Player
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/**
 * Manages the serialization and deserialization of game state for network transmission.
 */
class GameStateManager(private val game: Game) {

    companion object {
        private const val TAG = "GameStateManager"
    }
    
    /**
     * Serializes the current game state to a string for network transmission
     * 
     * @return A JSON string representing the current game state
     */
    fun serializeGameState(): String {
        val json = JSONObject()
        
        try {
            // Game state
            json.put("gameStarted", game.gameStarted)
            json.put("gameOver", game.gameOver)
            json.put("winnerId", game.winnerId)
            json.put("currentPlayerIndex", game.currentPlayerIndex)
            json.put("maxPlayers", game.maxPlayers)
            
            // Deck
            val deckJson = JSONObject()
            deckJson.put("cards", game.getDrawPileSize())
            json.put("deck", deckJson)
            
            // Discard pile
            val discardJson = JSONArray()
            val topCard = game.getTopDiscardCard()
            if (topCard != null) {
                discardJson.put(serializeCard(topCard))
            }
            json.put("discardPile", discardJson)
            
            // Players
            val playersJson = JSONArray()
            for (i in 0 until game.getActivePlayerCount()) {
                val player = game.getCurrentPlayer()
                game.nextTurn() // Move to the next player to get all players
                
                playersJson.put(serializePlayer(player))
            }
            json.put("players", playersJson)
            
            // Melds
            val meldsJson = JSONArray()
            for (meld in game.melds) {
                meldsJson.put(serializeMeld(meld))
            }
            json.put("melds", meldsJson)
            
        } catch (e: JSONException) {
            Log.e(TAG, "Error serializing game state: ${e.message}")
        }
        
        return json.toString()
    }
    
    /**
     * Deserializes a game state from a string and applies it to the game
     * 
     * @param gameState The JSON string representing the game state
     * @return True if the game state was successfully applied, false otherwise
     */
    fun deserializeGameState(gameState: String): Boolean {
        try {
            val json = JSONObject(gameState)
            
            // Game state
            game.gameStarted = json.getBoolean("gameStarted")
            game.gameOver = json.getBoolean("gameOver")
            game.winnerId = json.getInt("winnerId")
            game.currentPlayerIndex = json.getInt("currentPlayerIndex")
            
            // Players
            val playersJson = json.getJSONArray("players")
            val playersList = mutableListOf<Player>()
            
            for (i in 0 until playersJson.length()) {
                val playerJson = playersJson.getJSONObject(i)
                val player = deserializePlayer(playerJson)
                if (player != null) {
                    playersList.add(player)
                }
            }
            
            // Update the game's players
            // Note: This would need a method in the Game class to update all players
            // For now, we'll just log this
            Log.d(TAG, "Deserialized ${playersList.size} players")
            
            // Melds
            val meldsJson = json.getJSONArray("melds")
            game.melds.clear()
            
            for (i in 0 until meldsJson.length()) {
                val meldJson = meldsJson.getJSONObject(i)
                val meld = deserializeMeld(meldJson)
                if (meld != null) {
                    game.melds.add(meld)
                }
            }
            
            return true
            
        } catch (e: JSONException) {
            Log.e(TAG, "Error deserializing game state: ${e.message}")
            return false
        }
    }
    
    /**
     * Serializes a card to JSON
     * 
     * @param card The card to serialize
     * @return A JSON object representing the card
     */
    private fun serializeCard(card: Card): JSONObject {
        val json = JSONObject()
        json.put("suit", card.suit)
        json.put("rank", card.rank)
        return json
    }
    
    /**
     * Deserializes a card from JSON
     * 
     * @param json The JSON object representing the card
     * @return The deserialized Card object, or null if deserialization failed
     */
    private fun deserializeCard(json: JSONObject): Card? {
        return try {
            val suit = json.getString("suit")
            val rank = json.getInt("rank")
            Card(suit, rank)
        } catch (e: JSONException) {
            Log.e(TAG, "Error deserializing card: ${e.message}")
            null
        }
    }
    
    /**
     * Serializes a player to JSON
     * 
     * @param player The player to serialize
     * @return A JSON object representing the player
     */
    private fun serializePlayer(player: Player): JSONObject {
        val json = JSONObject()
        
        json.put("id", player.id)
        json.put("name", player.name)
        json.put("isLocal", player.isLocal)
        json.put("hasDrawnThisTurn", player.hasDrawnThisTurn)
        
        // Hand
        val handJson = JSONArray()
        for (card in player.hand) {
            handJson.put(serializeCard(card))
        }
        json.put("hand", handJson)
        
        // Melds
        val meldsJson = JSONArray()
        for (meld in player.melds) {
            meldsJson.put(serializeMeld(meld))
        }
        json.put("melds", meldsJson)
        
        return json
    }
    
    /**
     * Deserializes a player from JSON
     * 
     * @param json The JSON object representing the player
     * @return The deserialized Player object, or null if deserialization failed
     */
    private fun deserializePlayer(json: JSONObject): Player? {
        return try {
            val id = json.getInt("id")
            val name = json.getString("name")
            val isLocal = json.getBoolean("isLocal")
            
            val player = Player(id, name, isLocal)
            player.hasDrawnThisTurn = json.getBoolean("hasDrawnThisTurn")
            
            // Hand
            val handJson = json.getJSONArray("hand")
            for (i in 0 until handJson.length()) {
                val cardJson = handJson.getJSONObject(i)
                val card = deserializeCard(cardJson)
                if (card != null) {
                    player.addToHand(card)
                }
            }
            
            // Melds
            val meldsJson = json.getJSONArray("melds")
            for (i in 0 until meldsJson.length()) {
                val meldJson = meldsJson.getJSONObject(i)
                val meld = deserializeMeld(meldJson)
                if (meld != null) {
                    player.melds.add(meld)
                }
            }
            
            player
            
        } catch (e: JSONException) {
            Log.e(TAG, "Error deserializing player: ${e.message}")
            null
        }
    }
    
    /**
     * Serializes a meld to JSON
     * 
     * @param meld The meld to serialize
     * @return A JSON object representing the meld
     */
    private fun serializeMeld(meld: Meld): JSONObject {
        val json = JSONObject()
        
        json.put("type", meld.type)
        
        // Cards
        val cardsJson = JSONArray()
        for (card in meld.cards) {
            cardsJson.put(serializeCard(card))
        }
        json.put("cards", cardsJson)
        
        return json
    }
    
    /**
     * Deserializes a meld from JSON
     * 
     * @param json The JSON object representing the meld
     * @return The deserialized Meld object, or null if deserialization failed
     */
    private fun deserializeMeld(json: JSONObject): Meld? {
        return try {
            val type = json.getInt("type")
            
            val meld = Meld(type)
            
            // Cards
            val cardsJson = json.getJSONArray("cards")
            for (i in 0 until cardsJson.length()) {
                val cardJson = cardsJson.getJSONObject(i)
                val card = deserializeCard(cardJson)
                if (card != null) {
                    meld.addCard(card)
                }
            }
            
            meld
            
        } catch (e: JSONException) {
            Log.e(TAG, "Error deserializing meld: ${e.message}")
            null
        }
    }
}
