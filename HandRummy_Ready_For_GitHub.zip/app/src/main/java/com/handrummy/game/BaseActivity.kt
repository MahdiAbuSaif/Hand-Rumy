package com.handrummy.game

import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.handrummy.game.utils.LocaleHelper

/**
 * Base activity class that handles locale changes
 * All activities in the app should extend this class
 */
open class BaseActivity : AppCompatActivity() {

    override fun attachBaseContext(newBase: Context) {
        // Apply saved language setting before attaching the context
        super.attachBaseContext(LocaleHelper.onCreate(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}