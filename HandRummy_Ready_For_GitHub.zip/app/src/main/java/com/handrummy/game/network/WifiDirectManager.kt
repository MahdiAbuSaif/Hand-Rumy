package com.handrummy.game.network

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.NetworkInfo
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pDeviceList
import android.net.wifi.p2p.WifiP2pGroup
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.app.ActivityCompat
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/**
 * Manages WiFi Direct connections for the Hand Rummy game.
 * Handles device discovery, connection establishment, and data transfer.
 */
class WifiDirectManager(
    private val context: Context,
    private val onDeviceFound: (WifiP2pDevice) -> Unit,
    private val onConnectionSuccess: () -> Unit,
    private val onConnectionFailed: (String) -> Unit
) {

    companion object {
        private const val TAG = "WifiDirectManager"
        private const val PORT = 8988
    }
    
    private val manager: WifiP2pManager? by lazy {
        context.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager?
    }
    
    private val channel: WifiP2pManager.Channel? by lazy {
        manager?.initialize(context, context.mainLooper, null)
    }
    
    private val handler = Handler(Looper.getMainLooper())
    private val peers = mutableListOf<WifiP2pDevice>()
    
    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null
    private var isServer = false
    private var groupFormed = false
    
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null
    
    // Callback for data received from connected device
    private var onDataReceived: ((String) -> Unit)? = null
    
    // BroadcastReceiver for WiFi Direct events
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            
            when (action) {
                WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                    // Check if WiFi Direct is enabled
                    val state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1)
                    if (state != WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                        onConnectionFailed("WiFi Direct is not enabled")
                    }
                }
                
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                    // Request available peers
                    if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) 
                            != PackageManager.PERMISSION_GRANTED) {
                        onConnectionFailed("Location permission required for WiFi Direct")
                        return
                    }
                    
                    manager?.requestPeers(channel) { peerList: WifiP2pDeviceList ->
                        // Clear previous peers and add new ones
                        peers.clear()
                        peers.addAll(peerList.deviceList)
                        
                        // Notify about found devices
                        for (device in peers) {
                            onDeviceFound(device)
                        }
                    }
                }
                
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                    // Respond to connection changes
                    val networkInfo = intent.getParcelableExtra<NetworkInfo>(WifiP2pManager.EXTRA_NETWORK_INFO)
                    
                    if (networkInfo?.isConnected == true) {
                        // We are connected to a peer
                        manager?.requestConnectionInfo(channel) { info: WifiP2pInfo ->
                            // Handle connection info
                            handleConnectionInfo(info)
                        }
                    } else {
                        // We've been disconnected
                        groupFormed = false
                    }
                }
                
                WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION -> {
                    // Respond to this device's wifi state changing
                }
            }
        }
    }
    
    init {
        // Register for WiFi Direct broadcasts
        val intentFilter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        }
        context.registerReceiver(receiver, intentFilter)
    }
    
    /**
     * Checks if WiFi Direct is available on this device
     * 
     * @return True if WiFi Direct is available, false otherwise
     */
    fun isWifiDirectAvailable(): Boolean {
        return manager != null && channel != null
    }
    
    /**
     * Creates a WiFi Direct group (acts as a hotspot)
     */
    fun createGroup() {
        if (!isWifiDirectAvailable()) {
            onConnectionFailed("WiFi Direct not available on this device")
            return
        }
        
        // Check for necessary permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) 
                != PackageManager.PERMISSION_GRANTED) {
            onConnectionFailed("Location permission required for WiFi Direct")
            return
        }
        
        // Create a group
        manager?.createGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                isServer = true
                // Group created, start server socket
                startServerSocket()
            }
            
            override fun onFailure(reason: Int) {
                val message = when (reason) {
                    WifiP2pManager.ERROR -> "Internal error"
                    WifiP2pManager.BUSY -> "System is busy"
                    WifiP2pManager.P2P_UNSUPPORTED -> "WiFi Direct not supported"
                    else -> "Unknown error"
                }
                onConnectionFailed("Failed to create group: $message")
            }
        })
    }
    
    /**
     * Starts discovering nearby WiFi Direct peers
     */
    fun discoverPeers() {
        if (!isWifiDirectAvailable()) {
            onConnectionFailed("WiFi Direct not available on this device")
            return
        }
        
        // Check for necessary permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) 
                != PackageManager.PERMISSION_GRANTED) {
            onConnectionFailed("Location permission required for WiFi Direct")
            return
        }
        
        // Discover peers
        manager?.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                // Discovery started
                isServer = false
            }
            
            override fun onFailure(reason: Int) {
                val message = when (reason) {
                    WifiP2pManager.ERROR -> "Internal error"
                    WifiP2pManager.BUSY -> "System is busy"
                    WifiP2pManager.P2P_UNSUPPORTED -> "WiFi Direct not supported"
                    else -> "Unknown error"
                }
                onConnectionFailed("Failed to discover peers: $message")
            }
        })
    }
    
    /**
     * Connects to a specific WiFi Direct device
     * 
     * @param device The WiFi Direct device to connect to
     */
    fun connectToDevice(device: WifiP2pDevice) {
        if (!isWifiDirectAvailable()) {
            onConnectionFailed("WiFi Direct not available on this device")
            return
        }
        
        // Check for necessary permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) 
                != PackageManager.PERMISSION_GRANTED) {
            onConnectionFailed("Location permission required for WiFi Direct")
            return
        }
        
        // Configure connection
        val config = WifiP2pConfig().apply {
            deviceAddress = device.deviceAddress
            wps.setup = WpsInfo.PBC
        }
        
        // Connect to the device
        manager?.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                // Connection initiated
                isServer = false
            }
            
            override fun onFailure(reason: Int) {
                val message = when (reason) {
                    WifiP2pManager.ERROR -> "Internal error"
                    WifiP2pManager.BUSY -> "System is busy"
                    WifiP2pManager.P2P_UNSUPPORTED -> "WiFi Direct not supported"
                    else -> "Unknown error"
                }
                onConnectionFailed("Failed to connect to device: $message")
            }
        })
    }
    
    /**
     * Handles connection info after a WiFi Direct connection is established
     * 
     * @param info The WifiP2pInfo containing connection details
     */
    private fun handleConnectionInfo(info: WifiP2pInfo) {
        if (info.groupFormed) {
            groupFormed = true
            
            if (info.isGroupOwner) {
                // This device is the server
                isServer = true
                startServerSocket()
            } else {
                // This device is a client, connect to group owner
                val hostAddress = info.groupOwnerAddress
                connectToServer(hostAddress)
            }
        }
    }
    
    /**
     * Starts a server socket to accept incoming connections
     */
    private fun startServerSocket() {
        Thread {
            try {
                serverSocket = ServerSocket(PORT)
                
                // Wait for client connection
                clientSocket = serverSocket?.accept()
                
                // Connection established
                if (clientSocket != null) {
                    // Get input/output streams
                    inputStream = clientSocket?.getInputStream()
                    outputStream = clientSocket?.getOutputStream()
                    
                    // Start listening for data
                    startDataListener()
                    
                    // Notify connection success
                    handler.post {
                        onConnectionSuccess()
                    }
                }
            } catch (e: IOException) {
                Log.e(TAG, "Error creating server socket: ${e.message}")
                handler.post {
                    onConnectionFailed("Server socket error: ${e.message}")
                }
            }
        }.start()
    }
    
    /**
     * Connects to a server at the given address
     * 
     * @param address The server's IP address
     */
    private fun connectToServer(address: InetAddress) {
        Thread {
            try {
                clientSocket = Socket()
                
                // Connect with timeout
                clientSocket?.connect(InetSocketAddress(address, PORT), 5000)
                
                // Connection established
                if (clientSocket?.isConnected == true) {
                    // Get input/output streams
                    inputStream = clientSocket?.getInputStream()
                    outputStream = clientSocket?.getOutputStream()
                    
                    // Start listening for data
                    startDataListener()
                    
                    // Notify connection success
                    handler.post {
                        onConnectionSuccess()
                    }
                } else {
                    handler.post {
                        onConnectionFailed("Failed to connect to server")
                    }
                }
            } catch (e: IOException) {
                Log.e(TAG, "Error connecting to server: ${e.message}")
                handler.post {
                    onConnectionFailed("Connection error: ${e.message}")
                }
            }
        }.start()
    }
    
    /**
     * Sends data to the connected device
     * 
     * @param data The string data to send
     * @return True if the data was sent successfully, false otherwise
     */
    fun sendData(data: String): Boolean {
        if (outputStream == null) {
            return false
        }
        
        return try {
            outputStream?.write(data.toByteArray())
            true
        } catch (e: IOException) {
            Log.e(TAG, "Error sending data: ${e.message}")
            false
        }
    }
    
    /**
     * Sets the callback for receiving data from the connected device
     * 
     * @param callback The function to call when data is received
     */
    fun setOnDataReceivedListener(callback: (String) -> Unit) {
        onDataReceived = callback
    }
    
    /**
     * Starts listening for incoming data from the connected device
     */
    private fun startDataListener() {
        Thread {
            val buffer = ByteArray(1024)
            var bytes: Int
            
            // Keep listening to the InputStream
            while (true) {
                try {
                    // Read from the InputStream
                    bytes = inputStream?.read(buffer) ?: -1
                    
                    if (bytes > 0) {
                        // Convert to string
                        val data = String(buffer, 0, bytes)
                        
                        // Call the callback
                        handler.post {
                            onDataReceived?.invoke(data)
                        }
                    }
                } catch (e: IOException) {
                    Log.e(TAG, "Error reading data: ${e.message}")
                    break
                }
            }
        }.start()
    }
    
    /**
     * Removes the WiFi Direct group
     */
    fun removeGroup() {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) 
                != PackageManager.PERMISSION_GRANTED) {
            return
        }
        
        manager?.removeGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                groupFormed = false
            }
            
            override fun onFailure(reason: Int) {
                Log.e(TAG, "Failed to remove group: $reason")
            }
        })
    }
    
    /**
     * Cleans up WiFi Direct resources
     */
    fun cleanup() {
        // Unregister broadcast receiver
        try {
            context.unregisterReceiver(receiver)
        } catch (e: IllegalArgumentException) {
            // Receiver not registered
        }
        
        // Remove any WiFi Direct group
        if (groupFormed) {
            removeGroup()
        }
        
        // Close server socket
        try {
            serverSocket?.close()
        } catch (e: IOException) {
            Log.e(TAG, "Error closing server socket: ${e.message}")
        }
        
        // Close client socket
        try {
            clientSocket?.close()
        } catch (e: IOException) {
            Log.e(TAG, "Error closing client socket: ${e.message}")
        }
        
        // Close streams
        try {
            inputStream?.close()
            outputStream?.close()
        } catch (e: IOException) {
            Log.e(TAG, "Error closing streams: ${e.message}")
        }
    }
}
