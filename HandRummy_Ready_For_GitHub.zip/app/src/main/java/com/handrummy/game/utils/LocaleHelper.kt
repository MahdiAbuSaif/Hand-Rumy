package com.handrummy.game.utils

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.content.res.Resources
import android.os.Build
import java.util.Locale

/**
 * Helper class to manage app localization.
 * Provides functionality to change and persist language settings.
 */
class LocaleHelper {
    companion object {
        private const val SELECTED_LANGUAGE = "Locale.Helper.Selected.Language"
        private const val PREF_NAME = "HandRummyPreferences"

        /**
         * Sets the locale to the saved language preference or system default
         */
        fun onCreate(context: Context): Context {
            val lang = getPersistedLanguage(context)
            return setLocale(context, lang)
        }

        /**
         * Changes the app's locale to the specified language
         *
         * @param context The application context
         * @param language Language code (e.g., "en", "ar")
         * @return The updated context with new locale
         */
        fun setLocale(context: Context, language: String): Context {
            persist(context, language)
            
            // For API 24+, we need to create a context with the updated configuration
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                updateResources(context, language)
            } else {
                updateResourcesLegacy(context, language)
            }
        }

        /**
         * Retrieves the currently persisted language code
         *
         * @param context The application context
         * @return The language code (e.g., "en", "ar") or empty string for system default
         */
        fun getPersistedLanguage(context: Context): String {
            val preferences = getPreferences(context)
            return preferences.getString(SELECTED_LANGUAGE, "") ?: ""
        }

        /**
         * Persists the selected language preference
         *
         * @param context The application context
         * @param language The language code to persist
         */
        private fun persist(context: Context, language: String) {
            val preferences = getPreferences(context)
            val editor = preferences.edit()
            editor.putString(SELECTED_LANGUAGE, language)
            editor.apply()
        }

        /**
         * Updates resources for API 24+ (Nougat and above)
         */
        private fun updateResources(context: Context, language: String): Context {
            val locale = createLocale(language)
            Locale.setDefault(locale)
            
            val configuration = Configuration(context.resources.configuration)
            configuration.setLocale(locale)
            
            return context.createConfigurationContext(configuration)
        }

        /**
         * Updates resources for APIs below 24
         */
        @Suppress("DEPRECATION")
        private fun updateResourcesLegacy(context: Context, language: String): Context {
            val locale = createLocale(language)
            Locale.setDefault(locale)
            
            val resources = context.resources
            val configuration = resources.configuration
            configuration.locale = locale
            
            resources.updateConfiguration(configuration, resources.displayMetrics)
            
            return context
        }

        /**
         * Creates a Locale object from language code
         */
        private fun createLocale(language: String): Locale {
            return if (language.isEmpty()) {
                // Use system default
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    Resources.getSystem().configuration.locales.get(0)
                } else {
                    @Suppress("DEPRECATION")
                    Resources.getSystem().configuration.locale
                }
            } else {
                Locale(language)
            }
        }

        /**
         * Get app preferences
         */
        private fun getPreferences(context: Context): SharedPreferences {
            return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        }
    }
}